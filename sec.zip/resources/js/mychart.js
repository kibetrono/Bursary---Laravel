// import Chart from 'chart.js/auto';

// const labels = [
//     'January',
//     'February',
//     'March',
//     'April',
//     'May',
//     'June',
// ];

// const data = {
//     labels: labels,
//     datasets: [{
//         label: 'My First dataset',
//         backgroundColor: 'rgb(255, 99, 132)',
//         borderColor: 'rgb(255, 99, 132)',
//         data: [0, 10, 5, 2, 20, 30, 45],
//     }]
// };

// const config = {
//     type: 'line',
//     data: data,
//     options: {}
// };

// new Chart(
//     document.getElementById('myChart'),
//     config
// );




        // var years = @json($data['years']);
        // var approvedCounts = @json($data['approvedCounts']);
        // var rejectedCounts = @json($data['rejectedCounts']);

        // var ctx = document.getElementById('myChart').getContext('2d');
        // var chart = new Chart(ctx, {
        //     type: 'line',
        //     data: {
        //         labels: years,
        //         datasets: [
        //             {
        //                 label: 'Approved',
        //                 data: approvedCounts,
        //                 backgroundColor: 'rgba(75, 192, 192, 0.2)',
        //                 borderColor: 'rgba(75, 192, 192, 1)',
        //                 borderWidth: 1
        //             },
        //             {
        //                 label: 'Rejected',
        //                 data: rejectedCounts,
        //                 backgroundColor: 'rgba(255, 99, 132, 0.2)',
        //                 borderColor: 'rgba(255, 99, 132, 1)',
        //                 borderWidth: 1
        //             }
        //         ]
        //     },
        //     options: {
        //         scales: {
        //             y: {
        //                 beginAtZero: true,
        //                 precision: 0
        //             }
        //         }
        //     }
        // });
  