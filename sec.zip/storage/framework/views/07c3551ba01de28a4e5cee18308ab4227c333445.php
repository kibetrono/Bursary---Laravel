<?php $__env->startSection('title'); ?>
    Staffs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/dist/css/adminlte.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php
$startIndex = ($staffUsers->currentPage() - 1) * $staffUsers->perPage();
?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <h4>Staff List</h4>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Staffs</li>
                        </ol>
                    </div>
                </div>
                <div class="row mt-1">
                    <div class="col-sm-12">
                        <?php echo $__env->make('layouts.flash-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                </div>
            </div><!-- /.container-fluid -->

        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">

                    <!-- /.col -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-info">
                                <h3 class="card-title">Staffs</h3>
                                <div class="card-tools">
                                    
                                </div>
                            </div>

                            <div class="card-header mt-1">
                                <div class="card-tools">
                                    <form action="<?php echo e(route('staff.index')); ?>" method="GET">

                                        <div class="input-group input-group-sm">
                                            <input type="text" name="staff_user_search" value="<?php echo e(request('staff_user_search')); ?>"
                                                class="form-control float-right" placeholder="Search by name or email">

                                            <div class="input-group-append">
                                                <button type="submit" class="btn btn-default">
                                                    <i class="fas fa-search"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive p-1">
                                <table class="table table-hover text-nowrap table-bordered">
                                    <thead>
                                        <tr>
                                            <th style="width:10%">#</th>
                                            <th style="width:12%">Name</th>
                                            <th style="width:25%">email</th>
                                            <th style="width:25%">Date created</th>
                                            <th style="width:50%">Date updated</th>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view staff', 'edit staff', 'delete staff'])): ?>
                                            <th class="text-end">Action</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $staffUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($startIndex + $index + 1); ?></td>
                                                <td><?php echo e($user->name); ?></td>
                                                <td><a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></td>
                                                <td><?php echo e($user->created_at->format('Y-m-d')); ?></td>
                                                <td><?php echo e($user->updated_at->format('Y-m-d')); ?></td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view staff', 'edit staff', 'delete staff'])): ?>

                                                <td class="d-flex">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view staff')): ?>
                                                    <a href="<?php echo e(route('staff.show', encrypt($user->id))); ?>"
                                                        class="btn-sm btn btn-info mx-1" title="View"><i
                                                            class="fas fa-eye"></i></a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit staff')): ?>
                                                    <a href="<?php echo e(route('staff.edit', encrypt($user->id))); ?>" class="btn-sm btn btn-warning mx-1" title="Update"><i class="fas fa-edit"></i></a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete staff')): ?>
                                                    <form class="mx-1"
                                                        onclick="return confirm('Are you sure you want to delete <?php echo e($user->name); ?>?')"
                                                        action="<?php echo e(route('staff.destroy', $user->id)); ?>"
                                                        method="POST" title="Delete">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>

                                                        <button class="btn-sm btn btn-danger" type="submit"><i
                                                                class="fas fa-trash"></i></button>
                                                    </form>
                                                    <?php endif; ?>
                                                </td>
                                                <?php endif; ?>
                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td class="fas fa-folder-open"> No Staff Found</td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        <?php endif; ?>


                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>

                                        </tr>
                                    </tfoot>
                                </table>
                                <div class="row">
                                    <div class="col-md-12 pt-2">
                                        <?php if($staffUsers->hasPages()): ?>
                                            <div class="d-flex justify-content-end">
                                                <nav aria-label="Page navigation">
                                                    <ul class="pagination">
                                                        
                                                        <li
                                                            class="page-item <?php echo e($staffUsers->onFirstPage() ? 'disabled' : ''); ?>">
                                                            <a class="page-link"
                                                                href="<?php echo e($staffUsers->previousPageUrl()); ?>"
                                                                aria-label="Previous">
                                                                <span aria-hidden="true">&laquo;</span>
                                                            </a>
                                                        </li>

                                                        
                                                        <?php $__currentLoopData = $staffUsers->getUrlRange(1, $staffUsers->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li
                                                                class="page-item <?php echo e($staffUsers->currentPage() === $page ? 'active' : ''); ?>">
                                                                <a class="page-link"
                                                                    href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        
                                                        <li
                                                            class="page-item <?php echo e(!$staffUsers->hasMorePages() ? 'disabled' : ''); ?>">
                                                            <a class="page-link" href="<?php echo e($staffUsers->nextPageUrl()); ?>"
                                                                aria-label="Next">
                                                                <span aria-hidden="true">&raquo;</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->


    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(url('Admin/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(url('Admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(url('Admin/dist/js/adminlte.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SoftwaresKe/Bursary/bursary/resources/views/staff/staff_users/index.blade.php ENDPATH**/ ?>