<!DOCTYPE html>
<html lang="en">
<?php
    $settingsfields = \App\Models\SystemSetting::pluck('value', 'name')->toArray();
?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php if(isset($settingsfields['favicon'])): ?>
        <link rel="icon" href="<?php echo e(asset('storage/' . $settingsfields['favicon'])); ?>">
    <?php endif; ?>
    <title> <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/css/adminlte.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(url('Admin/css/main.css')); ?>">
</head>

<?php echo $__env->yieldContent('content'); ?>

<!-- jQuery -->
<script src="<?php echo e(url('Admin/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(url('Admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(url('Admin/js/adminlte.min.js')); ?>"></script>
<!-- Custom js -->
<script src="<?php echo e(url('Admin/js/auth/auth.js')); ?>"></script>

</html>
<?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/Backup/First/bursary/resources/views/layouts/auth.blade.php ENDPATH**/ ?>