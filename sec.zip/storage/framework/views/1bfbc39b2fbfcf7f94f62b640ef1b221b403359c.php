<?php $__env->startSection('title'); ?>
    Update User: <?php echo e($user->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/fontawesome-free/css/all.min.css')); ?>">

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/dist/css/adminlte.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(url('Admin/css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('Admin/css/users/edit.css')); ?>">

    <!-- Select2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <h4>Update User</h4>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">
                                <a href="<?php echo e(route('user.index')); ?>">Users</a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo e($user->email); ?></li>
                            <li class="breadcrumb-item active">Update</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-info">
                            <div class="card-header">
                                <h3 class="card-title">Update User: <?php echo e($user->email); ?></h3>
                                <div class="card-tools">
                                    
                                </div>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                            <form action="<?php echo e(route('user.update', $user->id)); ?>" method="POST" class="my-4">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">

                                    <label for="" class="px-4">Username</label>
                                    <div class="input-group mb-3 px-4">
                                        <input id="name" type="text"
                                            class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
                                            value="<?php echo e($user->name); ?>" required autocomplete="name" autofocus
                                            placeholder="Username">
                                        <div class="input-group-append">
                                            <div class="input-group-text"><span class="fas fa-user"></span></div>
                                        </div>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <label for="" class="px-4">Email Address</label>
                                    <div class="input-group mb-3 px-4">
                                        <input id="email" type="email"
                                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                            value="<?php echo e($user->email); ?>" required autocomplete="email"
                                            placeholder="Email Address">
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fas fa-envelope"></span>
                                            </div>

                                        </div>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <label for="" class="px-4">Password</label>
                                    <div class="input-group mb-3 px-4">
                                        <input id="password" type="password"
                                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                            autocomplete="new-password" placeholder="Password">
                                        <!-- Password visibility toggle -->
                                        <div class="input-group-append">
                                            <span class="input-group-text password-toggle"
                                                onclick="togglePasswordVisibility()">
                                                <i class="fas fa-eye"></i>
                                            </span>
                                        </div>
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                    </div>
                                    <label for="" class="px-4">Confirm Password</label>

                                    <div class="input-group mb-3 px-4">
                                        <input id="password-confirm" type="password" name="password_confirmation"
                                            class="form-control" placeholder="Retype password">
                                        <div class="input-group-append">
                                            <span class="input-group-text password-toggle-confirm"
                                                onclick="togglePasswordConfirmVisibility()">
                                                <i class="fas fa-eye"></i>
                                            </span>
                                        </div>
                                    </div>

                                    <label for="" class="px-4">Role</label>
                                    <div class="input-group mb-3 px-4">
                                        <select class="form-control" id="user_edit_select_role" name="role">
                                            <option value="">Select Role</option>
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($role->id); ?>"
                                                    <?php echo e($user->roles->contains('id', $role->id) ? 'selected' : 'tt'); ?>>
                                                    <?php echo e($role->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="input-group-append">
                                            <div class="input-group-text">
                                                <span class="fas fa-tasks"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="px-4">
                                        <button style="border:unset" id="updateUserButton" type="submit"
                                            class="btn-md btn btn-success btn-block"><i class="fa fa-edit"></i> Update
                                            User</button>
                                    </div>

                                </div>

                            </form>
                        </div>
                        <!-- /.card -->



                    </div>
                    <!--/.col (left) -->
                    <!-- right column -->

                    <!--/.col (right) -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(url('Admin/plugins/jquery/jquery.min.js')); ?>"></script>

    <!-- Bootstrap 4 -->
    <script src="<?php echo e(url('Admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <script src="<?php echo e(url('Admin/plugins/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(url('Admin/dist/js/adminlte.min.js')); ?>"></script>

    

    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <!-- Select2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>

    <!-- Custom js -->
    <script src="<?php echo e(url('Admin/js/users/app.js')); ?>"></script>
    <script src="<?php echo e(url('Admin/js/users/select2.js')); ?>"></script>
    <script src="<?php echo e(url('Admin/js/users/edit.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SoftwaresKe/Bursary/bursary/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>