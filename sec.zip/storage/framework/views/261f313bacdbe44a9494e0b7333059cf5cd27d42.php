<?php echo e($slot); ?>

<?php /**PATH /var/www/html/SoftwaresKe/Bursary/bursary/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>