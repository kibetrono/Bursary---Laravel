<?php $__env->startComponent('mail::message'); ?>
    <p>Hello <?php echo e($user->name); ?>,</p>
    <p> We regret that your bursary application for academic year <?php echo e($year); ?> was unsuccessful as you did not meet all the requirements needed.</p>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/Backup/First/bursary/resources/views/admin/customEmail/bursary-reject.blade.php ENDPATH**/ ?>