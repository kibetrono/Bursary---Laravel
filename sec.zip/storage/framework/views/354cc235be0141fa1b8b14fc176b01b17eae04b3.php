<!DOCTYPE html>
<html lang="en">
<?php
$settingsfields = \App\Models\SystemSetting::pluck('value', 'name')->toArray();
?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <?php if(isset($settingsfields['favicon'])): ?>
    <link rel="icon" href="<?php echo e(route('fetchFavicon', ['filename' => basename($settingsfields['favicon'])])); ?>">
    <?php endif; ?>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->yieldContent('css'); ?>
    
    <link rel="stylesheet" href="<?php echo e(url('Admin/css/header.css')); ?>">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
    <!-- ./wrapper -->

    <?php echo $__env->yieldContent('js'); ?>

</body>

</html>
<?php /**PATH /var/www/html/SoftwaresKe/Bursary/bursary/resources/views/layouts/app.blade.php ENDPATH**/ ?>