
<?php $__env->startComponent('mail::message'); ?>
    
    Congratulations <?php echo e($user->name); ?>,
    
    
    Congratulations, you have successfully applied for the bursary for the academic year <?php echo e($year); ?>. We appreciate your interest in our bursary program.

    
    Our team is currently reviewing your application. We carefully consider each application, and it may take some time to evaluate all the candidates.

    
    In the meantime, here are the next steps in the application process:
    
    Please ensure that all the required documents are complete and accurate. Any missing or incorrect information may delay the review process.
    We will contact you via email if any additional information or documents are needed.
    Once the review process is completed, you will be notified of the outcome via email.

    
    If you have any questions regarding your application or need further assistance, don't hesitate to reach out to visit our offices.

    
    Best regards,
    The <?php echo e(config('app.name')); ?> Team

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/SoftwaresKe/Bursary/bursary/resources/views/admin/customEmail/bursary-successful-application.blade.php ENDPATH**/ ?>