<?php $__env->startSection('title'); ?>
    Polling Stations
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/fontawesome-free/css/all.min.css')); ?>">

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/dist/css/adminlte.min.css')); ?>">
    
<?php $__env->stopSection(); ?>

<?php
$startIndex = ($pollingStations->currentPage() - 1) * $pollingStations->perPage();
?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h3>Polling Stations</h3>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Polling Stations</li>
                        </ol>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <?php echo $__env->make('layouts.flash-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                </div>
            </div><!-- /.container-fluid -->

        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">

                    <!-- /.col -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-info">
                                <h3 class="card-title">Polling Stations</h3>
                                <div class="card-tools">
                                    
                                </div>
                            </div>

                            <div class="card-header mt-1">
                                <h3 class="card-title"><i class="fas fa-map-marker"></i> Polling Station Lists</h3>

                                <div class="card-tools">
                                    <form action="<?php echo e(route('polling-station.index')); ?>" method="GET">

                                        <div class="input-group input-group-sm">
                                            <input type="text" name="pollingstation_search" value="<?php echo e(request('pollingstation_search')); ?>"
                                                class="form-control float-right" placeholder="Search by name">

                                            <div class="input-group-append">
                                                <button type="submit" class="btn btn-default">
                                                    <i class="fas fa-search"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive p-1">
                                <table class="table table-hover text-nowrap table-bordered table-striped">

                                    <thead>
                                        <tr>
                                            <th style="width:5%">#</th>
                                            <th style="width:20%">Name</th>
                                            <th style="width:20%">Sub-Location</th>
                                            <th style="width:20%">Date Created</th>
                                            <th style="width:20%">Date Updated</th>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create location','update location','delete location'])): ?>                                            
                                            <th class="d-flex justify-content-center">Action</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $pollingStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$pollingStation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($startIndex + $index + 1); ?></td>
                                                <td><?php echo e($pollingStation->name); ?></td>
                                                <td><?php echo e($pollingStation->sublocation->name); ?></td>
                                                <td><?php echo e($pollingStation->created_at->format('Y-m-d')); ?></td>
                                                <td><?php echo e($pollingStation->updated_at->format('Y-m-d')); ?></td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create location', 'view location', 'update location','delete location'])): ?>                                            
                                                <td class="text-end">
                                                    <div class="d-flex justify-content-center">
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update location')): ?>
                                                            <a href="<?php echo e(route('polling-station.edit', encrypt($pollingStation->id))); ?>" class="btn-sm btn btn-warning mx-1" title="Update"><i class="fas fa-edit"></i></a>
                                                        <?php endif; ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete location')): ?>
                                                            <form class="mx-1" onclick="return confirm('Are you sure you want to delete <?php echo e($pollingStation->name); ?>?')" action="<?php echo e(route('polling-station.destroy', $pollingStation->id)); ?>" method="POST" title="Delete">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button class="btn-sm btn btn-danger" type="submit"><i class="fas fa-trash"></i></button>
                                                            </form>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <?php endif; ?>
                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                            <tr>
                                                <td colspan="6" class="text-center text-bold">
                                                    <i class="fas fa-folder-open"></i> No Polling Station Found
                                                </td>
                                                
                                            </tr>
                                        <?php endif; ?>

                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>

                                        </tr>
                                    </tfoot>
                                </table>
                                <div class="row">
                                    <div class="col-md-12 pt-2">
                                        <?php if($pollingStations->hasPages()): ?>
                                            <div class="d-flex justify-content-end">
                                                <nav aria-label="Page navigation">
                                                    <ul class="pagination">
                                                        
                                                        <li
                                                            class="page-item <?php echo e($pollingStations->onFirstPage() ? 'disabled' : ''); ?>">
                                                            <a class="page-link"
                                                                href="<?php echo e($pollingStations->previousPageUrl()); ?>"
                                                                aria-label="Previous">
                                                                <span aria-hidden="true">&laquo;</span>
                                                            </a>
                                                        </li>

                                                        
                                                        <?php $__currentLoopData = $pollingStations->getUrlRange(1, $pollingStations->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li
                                                                class="page-item <?php echo e($pollingStations->currentPage() === $page ? 'active' : ''); ?>">
                                                                <a class="page-link"
                                                                    href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        
                                                        <li
                                                            class="page-item <?php echo e(!$pollingStations->hasMorePages() ? 'disabled' : ''); ?>">
                                                            <a class="page-link" href="<?php echo e($pollingStations->nextPageUrl()); ?>"
                                                                aria-label="Next">
                                                                <span aria-hidden="true">&raquo;</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->

    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(url('Admin/plugins/jquery/jquery.min.js')); ?>"></script>

    <!-- Bootstrap 4 -->
    <script src="<?php echo e(url('Admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(url('Admin/dist/js/adminlte.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/Backup/First/bursary/resources/views/admin/polling-stations/index.blade.php ENDPATH**/ ?>