<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(url('home')); ?>" class="brand-link">

        <?php if(isset($settingsfields['logo'])): ?>
            <img src="<?php echo e(route('fetchLogo', ['filename' => basename($settingsfields['logo'])])); ?>" alt="Logo"
                class="brand-image img-circle elevation-3 bg-light"
                style="opacity: .8; border-radius: 100px; width: 35px; height: 40px;">
        <?php else: ?>
            <img src="<?php echo e(url('./assets/image/noLogo.png')); ?>" alt="Logo"
                class="brand-image img-circle elevation-3 bg-light"
                style="opacity: .8;border-radius:100px;width:35px;height:40px">
        <?php endif; ?>

        <?php if(isset($settingsfields['title_text'])): ?>
            <span class="brand-text font-weight-light"><?php echo e($settingsfields['title_text']); ?></span>
        <?php else: ?>
            <span class="brand-text font-weight-light">Title Text</span>
        <?php endif; ?>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img class="img-circle elevation-2" alt="User Image" src="/assets/image/default_image.png">

            </div>
            <div class="info">
                <?php if(Auth::check()): ?>
                    <a href="<?php echo e(route('profile.show', encrypt(Auth::user()->id))); ?>" class="d-block">
                        <?php echo e(Auth::user()->name); ?></a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                data-accordion="false">
                <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
                <li class="<?php echo e(request()->is(['admin/dashboard']) ? 'nav-item' : 'nav-item'); ?>">
                    <a href="<?php echo e(url('home')); ?>"
                        class="<?php echo e(request()->is(['admin/dashboard', 'staff/dashboard', 'home', 'user-dashboard']) ? 'nav-link active' : 'nav-link'); ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Dashboard
                        </p>
                    </a>

                    <?php if(Auth::check()): ?>
                        <?php if(Auth::user()->roles->count() === 0): ?>
                            
                <li class="<?php echo e(request()->is(['user-bursary/*']) ? 'nav-item menu-open' : 'nav-item'); ?>">
                    <a href="#" class="<?php echo e(request()->is(['user-bursary/*']) ? 'nav-link active' : 'nav-link'); ?>">
                        <i class="nav-icon fas fa-wallet"></i>
                        <p>
                            Bursary
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('user.bursary.create.form')); ?>"
                                class="<?php echo e(request()->is(['user-bursary/apply', '']) ? 'nav-link active' : 'nav-link'); ?>">
                                &nbsp
                                <i class="fas fa-hand-holding"></i>
                                <p>&nbsp Apply bursary</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('user.bursary.history', encrypt(Auth::user()->id))); ?>"
                                class="<?php echo e(request()->is(['user-bursary/history/*']) ? 'nav-link active' : 'nav-link'); ?>">
                                &nbsp
                                <i class="fas fa-history"></i>
                                <p>&nbsp History</p>
                            </a>
                        </li>

                    </ul>
                </li>
                

                
                <li class="nav-item">
                    <a href="<?php echo e(url('notifications')); ?>"
                        class="<?php echo e(request()->is(['notifications']) ? 'nav-link active' : 'nav-link'); ?>">
                        <i class="nav-icon fas fa-bell"></i>
                        <p>
                            Notifications
                        </p>
                    </a>
                </li>
                
                <?php endif; ?>
                <?php endif; ?>
                </li>

                
                <?php if(Gate::check('manage bursary')): ?>
                    <li class="nav-header">APPLICATIONS</li>
                    
                    <li class="nav-item">
                        <a href="<?php echo e(url('bursary')); ?>"
                            class="<?php echo e(request()->is(['bursary', 'bursary/*', 'admin/bursary/*']) ? 'nav-link active' : 'nav-link'); ?>">
                            <i class="nav-icon fas fa-hand-holding"></i>
                            <p>
                                Bursary Applications
                            </p>
                        </a>
                    </li>
                    

                    
                    <li
                        class="<?php echo e(request()->is(['approved-applications', 'rejected-applications']) ? 'nav-item menu-open' : 'nav-item'); ?>">
                        <a href="#"
                            class="<?php echo e(request()->is(['approved-applications', 'rejected-applications']) ? 'nav-link active' : 'nav-link'); ?>">
                            <i class="nav-icon fas fa-info-circle"></i>
                            <p>
                                Application Status
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('approved.applications')); ?>"
                                    class="<?php echo e(request()->is(['approved-applications']) ? 'nav-link active' : 'nav-link'); ?>">
                                    &nbsp
                                    <i class="fas fa-thumbs-up"></i>
                                    <p>&nbsp Approved Applications</p>
                                </a>
                            </li>

                            <li class="nav-item">
                                <a href="<?php echo e(route('rejected.applications')); ?>"
                                    class="<?php echo e(request()->is(['rejected-applications']) ? 'nav-link active' : 'nav-link'); ?>">
                                    &nbsp
                                    <i class="fas fa-thumbs-down"></i>
                                    <p>&nbsp Rejected Applications</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    
                <?php endif; ?>
                

                

                <?php if(Gate::check('manage location')): ?>
                    <li class="nav-header">LOCATIONS</li>

                    
                    <li
                        class="<?php echo e(request()->is(['admin/county', 'admin/county/*']) ? 'nav-item menu-open' : 'nav-item'); ?>">
                        <a href="#"
                            class="<?php echo e(request()->is(['admin/county', 'admin/county/*']) ? 'nav-link active' : 'nav-link'); ?>">
                            <i class="nav-icon fas fa-map-marker"></i>
                            <p>
                                Counties
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('county.index')); ?>"
                                    class="<?php echo e(request()->is(['admin/county']) ? 'nav-link active' : 'nav-link'); ?>">
                                    &nbsp
                                    <i class="fas fa-list"></i>
                                    <p>&nbsp List</p>
                                </a>
                            </li>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create location')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('county.create')); ?>"
                                        class="<?php echo e(request()->is(['admin/county/create']) ? 'nav-link active' : 'nav-link'); ?>">
                                        &nbsp
                                        <i class="fas fa-plus-circle"></i>
                                        <p>&nbsp Add</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                        </ul>
                    </li>
                    

                    
                    <li
                        class="<?php echo e(request()->is(['admin/constituency', 'admin/county-constituency/create-multiple', 'admin/constituency/*']) ? 'nav-item menu-open' : 'nav-item'); ?>">
                        <a href="#"
                            class="<?php echo e(request()->is(['admin/constituency', 'admin/county-constituency/create-multiple', 'admin/constituency/*']) ? 'nav-link active' : 'nav-link'); ?>">
                            <i class="nav-icon fas fa-map-marker"></i>
                            <p>
                                Constituencies
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('constituency.index')); ?>"
                                    class="<?php echo e(request()->is(['admin/constituency']) ? 'nav-link active' : 'nav-link'); ?>">
                                    &nbsp
                                    <i class="fas fa-list"></i>
                                    <p>&nbsp List</p>
                                </a>
                            </li>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create location')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('constituency.create')); ?>"
                                        class="<?php echo e(request()->is(['admin/constituency/create']) ? 'nav-link active' : 'nav-link'); ?>">
                                        &nbsp
                                        <i class="fas fa-plus-circle"></i>
                                        <p>&nbsp Add</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('constituency.create.multiple')); ?>"
                                        class="<?php echo e(request()->is(['admin/county-constituency/create-multiple']) ? 'nav-link active' : 'nav-link'); ?>">
                                        &nbsp
                                        <i class="fas fa-plus-circle"></i>
                                        <p>&nbsp Add Multiple</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                        </ul>
                    </li>
                    

                    
                    <li
                        class="<?php echo e(request()->is(['admin/ward', 'admin/county-ward/create-multiple', 'admin/ward/*']) ? 'nav-item menu-open' : 'nav-item'); ?>">
                        <a href="#"
                            class="<?php echo e(request()->is(['admin/ward', 'admin/county-ward/create-multiple', 'admin/ward/*']) ? 'nav-link active' : 'nav-link'); ?>">
                            <i class="nav-icon fas fa-map-marker"></i>
                            <p>
                                Wards
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('ward.index')); ?>"
                                    class="<?php echo e(request()->is(['admin/ward']) ? 'nav-link active' : 'nav-link'); ?>">
                                    &nbsp
                                    <i class="fas fa-list"></i>
                                    <p>&nbsp List</p>
                                </a>
                            </li>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create location')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('ward.create')); ?>"
                                        class="<?php echo e(request()->is(['admin/ward/create']) ? 'nav-link active' : 'nav-link'); ?>">
                                        &nbsp
                                        <i class="fas fa-plus-circle"></i>
                                        <p>&nbsp Add</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('ward.create.multiple')); ?>"
                                        class="<?php echo e(request()->is(['admin/county-ward/create-multiple']) ? 'nav-link active' : 'nav-link'); ?>">
                                        &nbsp
                                        <i class="fas fa-plus-circle"></i>
                                        <p>&nbsp Add Multiple</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                        </ul>
                    </li>
                    

                    
                    <li
                        class="<?php echo e(request()->is(['admin/location', 'admin/locations/create-multiple', 'admin/location/*']) ? 'nav-item menu-open' : 'nav-item'); ?>">
                        <a href="#"
                            class="<?php echo e(request()->is(['admin/location', 'admin/locations/create-multiple', 'admin/location/*']) ? 'nav-link active' : 'nav-link'); ?>">
                            <i class="nav-icon fas fa-map-marker"></i>
                            <p>
                                Locations
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('location.index')); ?>"
                                    class="<?php echo e(request()->is(['admin/location']) ? 'nav-link active' : 'nav-link'); ?>">
                                    &nbsp
                                    <i class="fas fa-list"></i>
                                    <p>&nbsp List</p>
                                </a>
                            </li>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create location')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('location.create')); ?>"
                                        class="<?php echo e(request()->is(['admin/location/create']) ? 'nav-link active' : 'nav-link'); ?>">
                                        &nbsp
                                        <i class="fas fa-plus-circle"></i>
                                        <p>&nbsp Add</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('location.create.multiple')); ?>"
                                        class="<?php echo e(request()->is(['admin/locations/create-multiple']) ? 'nav-link active' : 'nav-link'); ?>">
                                        &nbsp
                                        <i class="fas fa-plus-circle"></i>
                                        <p>&nbsp Add Multiple</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                        </ul>
                    </li>
                    

                    
                    <li
                        class="<?php echo e(request()->is(['admin/sub-location', 'admin/sub-locations/create-multiple', 'admin/sub-location/*']) ? 'nav-item menu-open' : 'nav-item'); ?>">
                        <a href="#"
                            class="<?php echo e(request()->is(['admin/sub-location', 'admin/sub-locations/create-multiple', 'admin/sub-location/*']) ? 'nav-link active' : 'nav-link'); ?>">
                            <i class="nav-icon fas fa-map-marker"></i>
                            <p>
                                Sub-locations
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('sub-location.index')); ?>"
                                    class="<?php echo e(request()->is(['admin/sub-location']) ? 'nav-link active' : 'nav-link'); ?>">
                                    &nbsp
                                    <i class="fas fa-list"></i>
                                    <p>&nbsp List</p>
                                </a>
                            </li>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create location')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('sub-location.create')); ?>"
                                        class="<?php echo e(request()->is(['admin/sub-location/create']) ? 'nav-link active' : 'nav-link'); ?>">
                                        &nbsp
                                        <i class="fas fa-plus-circle"></i>
                                        <p>&nbsp Add</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('sub-location.create.multiple')); ?>"
                                        class="<?php echo e(request()->is(['admin/sub-locations/create-multiple']) ? 'nav-link active' : 'nav-link'); ?>">
                                        &nbsp
                                        <i class="fas fa-plus-circle"></i>
                                        <p>&nbsp Add Multiple</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                        </ul>
                    </li>
                    

                    
                    <li
                        class="<?php echo e(request()->is(['admin/polling-station', 'admin/polling-stations/create-multiple', 'admin/polling-station/*']) ? 'nav-item menu-open' : 'nav-item'); ?>">
                        <a href="#"
                            class="<?php echo e(request()->is(['admin/polling-station', 'admin/polling-stations/create-multiple', 'admin/polling-station/*']) ? 'nav-link active' : 'nav-link'); ?>">
                            <i class="nav-icon fas fa-map-marker"></i>
                            <p>
                                Polling-stations
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('polling-station.index')); ?>"
                                    class="<?php echo e(request()->is(['admin/polling-station']) ? 'nav-link active' : 'nav-link'); ?>">
                                    &nbsp
                                    <i class="fas fa-list"></i>
                                    <p>&nbsp List</p>
                                </a>
                            </li>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create location')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('polling-station.create')); ?>"
                                        class="<?php echo e(request()->is(['admin/polling-station/create']) ? 'nav-link active' : 'nav-link'); ?>">
                                        &nbsp
                                        <i class="fas fa-plus-circle"></i>
                                        <p>&nbsp Add</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('polling-station.create.multiple')); ?>"
                                        class="<?php echo e(request()->is(['admin/polling-stations/create-multiple']) ? 'nav-link active' : 'nav-link'); ?>">
                                        &nbsp
                                        <i class="fas fa-plus-circle"></i>
                                        <p>&nbsp Add Multiple</p>
                                    </a>
                                </li>
                            <?php endif; ?>

                        </ul>
                    </li>
                    
                <?php endif; ?>

                

                <?php if(Gate::check('manage user') ||
                        Gate::check('manage staff') ||
                        Gate::check('manage role') ||
                        Gate::check('manage permission') ||
                        Gate::check('manage application period')): ?>

                    <li class="nav-header">ADMINISTRATION</li>
                    
                    
                    

                    
                    <?php if(Gate::check('manage role')): ?>
                        <li
                            class="<?php echo e(request()->is(['admin/role', 'admin/role/*']) ? 'nav-item menu-open' : 'nav-item'); ?>">
                            <a href="#"
                                class="<?php echo e(request()->is(['admin/role', 'admin/role/*']) ? 'nav-link active' : 'nav-link'); ?>">
                                <i class="nav-icon fas fa-tasks"></i>
                                <p>
                                    Roles
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo e(route('role.index')); ?>"
                                        class="<?php echo e(request()->is(['admin/role']) ? 'nav-link active' : 'nav-link'); ?>">
                                        &nbsp
                                        <i class="fas fa-list"></i>
                                        <p>&nbsp List</p>
                                    </a>
                                </li>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create role')): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('role.create')); ?>"
                                            class="<?php echo e(request()->is(['admin/role/create']) ? 'nav-link active' : 'nav-link'); ?>">
                                            &nbsp
                                            <i class="fas fa-plus-circle"></i>
                                            <p>&nbsp Add</p>
                                        </a>
                                    </li>
                                <?php endif; ?>

                            </ul>
                        </li>
                    <?php endif; ?>
                    


                    
                    <?php if(Gate::check('manage staff')): ?>
                        <li
                            class="<?php echo e(request()->is(['admin/staff', 'admin/staff/*', 'admin/staff-user-view-approved-tasks/*', 'admin/staff-user-view-rejected-tasks/*']) ? 'nav-item menu-open' : 'nav-item'); ?>">
                            <a href="#"
                                class="<?php echo e(request()->is(['admin/staff', 'admin/staff/*', 'admin/staff-user-view-approved-tasks/*', 'admin/staff-user-view-rejected-tasks/*']) ? 'nav-link active' : 'nav-link'); ?>">
                                <i class="nav-icon fas fa-users"></i>
                                <p>
                                    Staffs
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo e(route('staff.index')); ?>"
                                        class="<?php echo e(request()->is(['admin/staff']) ? 'nav-link active' : 'nav-link'); ?>">
                                        &nbsp
                                        <i class="fas fa-list"></i>
                                        <p>&nbsp List</p>
                                    </a>
                                </li>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create staff')): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('staff.create')); ?>"
                                            class="<?php echo e(request()->is(['admin/staff/create']) ? 'nav-link active' : 'nav-link'); ?>">
                                            &nbsp
                                            <i class="fas fa-plus-circle"></i>
                                            <p>&nbsp Add</p>
                                        </a>
                                    </li>
                                <?php endif; ?>

                            </ul>
                        </li>
                    <?php endif; ?>
                    

                    
                    <?php if(Gate::check('manage user')): ?>
                        <li
                            class="<?php echo e(request()->is(['admin/user', 'admin/user/*']) ? 'nav-item menu-open' : 'nav-item'); ?>">
                            <a href="#"
                                class="<?php echo e(request()->is(['admin/user', 'admin/user/*']) ? 'nav-link active' : 'nav-link'); ?>">
                                <i class="nav-icon fas fa-user-secret"></i>
                                <p>
                                    Users
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo e(route('user.index')); ?>"
                                        class="<?php echo e(request()->is(['admin/user']) ? 'nav-link active' : 'nav-link'); ?>">
                                        &nbsp
                                        <i class="fas fa-list"></i>
                                        <p>&nbsp List</p>
                                    </a>
                                </li>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create user')): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('user.create')); ?>"
                                            class="<?php echo e(request()->is(['admin/user/create']) ? 'nav-link active' : 'nav-link'); ?>">
                                            &nbsp
                                            <i class="fas fa-plus-circle"></i>
                                            <p>&nbsp Add</p>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    

                    
                    <?php if(Gate::check('manage application period')): ?>
                        <li
                            class="<?php echo e(request()->is(['admin/application-period', 'admin/application-period/*']) ? 'nav-item menu-open' : 'nav-item'); ?>">
                            <a href="#"
                                class="<?php echo e(request()->is(['admin/application-period', 'admin/application-period/*']) ? 'nav-link active' : 'nav-link'); ?>">
                                <i class="nav-icon fas fa-calendar-alt"></i>
                                <p>
                                    Application Period
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo e(route('application-period.index')); ?>"
                                        class="<?php echo e(request()->is(['admin/application-period']) ? 'nav-link active' : 'nav-link'); ?>">
                                        &nbsp
                                        <i class="fas fa-list"></i>
                                        <p>&nbsp List</p>
                                    </a>
                                </li>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create application period')): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('application-period.create')); ?>"
                                            class="<?php echo e(request()->is(['admin/application-period/create']) ? 'nav-link active' : 'nav-link'); ?>">
                                            &nbsp
                                            <i class="fas fa-plus-circle"></i>
                                            <p>&nbsp Add</p>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    
                <?php endif; ?>

                
                <?php if(Gate::check('manage system setting')): ?>
                    <li class="nav-header">SETTINGS</li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('system-setting.index')); ?>"
                            class="<?php echo e(request()->is(['admin/system-setting']) ? 'nav-link active' : 'nav-link'); ?>">
                            <i class="nav-icon fas fa-cog"></i>
                            <p>
                                System Settings
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                
            </ul>
        </nav>
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH /var/www/html/SoftwaresKe/Bursary/bursary/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>