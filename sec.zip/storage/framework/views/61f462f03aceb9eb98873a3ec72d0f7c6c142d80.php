<?php $__env->startComponent('mail::message'); ?>
    <p>Congratulations <?php echo e($name); ?></p>
    <p>You have successfully been assigned a <?php echo e($role->name); ?> role. Kindly adhere to all the rules required as <?php echo e($role->name); ?></p>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/Backup/First/bursary/resources/views/admin/customEmail/role-assigned.blade.php ENDPATH**/ ?>