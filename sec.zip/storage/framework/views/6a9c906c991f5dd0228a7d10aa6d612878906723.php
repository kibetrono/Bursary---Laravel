
<?php $__env->startComponent('mail::message'); ?>
    
    # Congratulations, <?php echo e($name); ?>!

    
    You have been assigned the role of "<?php echo e($role->name); ?>". We are excited to have you on board!

    ou are now among out team staff

    - Role Name: <?php echo e($role->name); ?>

    - Permissions: 
    <?php $__empty_1 = true; $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        - <?php echo e(ucfirst($permission->name)); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="fas fa-folder-open" style="font-weight: normal"> No
            Permission(s) Found</p>
    <?php endif; ?>

    Best regards,
    The <?php echo e(config('app.name')); ?> Team

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/SoftwaresKe/Bursary/bursary/resources/views/admin/customEmail/create-staff.blade.php ENDPATH**/ ?>