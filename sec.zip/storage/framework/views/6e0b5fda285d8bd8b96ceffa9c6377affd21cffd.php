<?php $__env->startSection('title'); ?>
    Bursary Application List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/dist/css/adminlte.min.css')); ?>">
    <!-- Include DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
    
    <link rel="stylesheet" href="<?php echo e(url('Admin/css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('Admin/css/bursary/index.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('Admin/css/bursary/show.css')); ?>">
<?php $__env->stopSection(); ?>
<?php
    $startIndex = ($bursaries->currentPage() - 1) * $bursaries->perPage();
    $user = Auth::user();
?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <h4>Bursary Application List</h4>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Bursary Application List</li>
                        </ol>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <?php echo $__env->make('layouts.flash-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                </div>
            </div><!-- /.container-fluid -->

        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">

                    <!-- /.col -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-info">
                                <h3 class="card-title">Application List </h3>
                                <div id="loadingMessageBursaryPage">
                                    <div class="loading-container">
                                        <strong>
                                            <i class="fas fa-spinner fa-spin"></i> &nbsp; Loading...
                                        </strong>
                                    </div>
                                </div>
                                <div class="card-tools"></div>
                            </div>

                            <!-- /.card-header -->
                            <div class="card-body p-1">
                                <table id="users-table" class="table table-bordered table-hover table-responsive">
                                    <thead>
                                        <tr style="white-space: nowrap;">
                                            <th><input type="checkbox" id="select-all-checkbox"></th>
                                            <th>#</th>
                                            <th>Applicant info.</th>
                                            <th>Institution info.</th>
                                            <th>Total Fees</th>
                                            <th>Balance</th>
                                            <th>Constituency</th>
                                            <th>Date Applied</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $bursaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$bursary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <?php
                                                $trimmed_fName = strlen($bursary->first_name) > 10 ? substr($bursary->first_name, 0, 10) . '...' : $bursary->first_name;
                                                $trimmed_lName = strlen($bursary->last_name) > 10 ? substr($bursary->last_name, 0, 10) . '...' : $bursary->last_name;
                                                $trimmed_adm = strlen($bursary->adm_or_reg_no) > 10 ? substr($bursary->adm_or_reg_no, 0, 10) . '...' : $bursary->adm_or_reg_no;
                                                $trimmed_institution = strlen($bursary->institution_name) > 20 ? substr($bursary->institution_name, 0, 15) . '...' : $bursary->institution_name;
                                                
                                            ?>
                                            <tr style="white-space: nowrap;">
                                                <td>
                                                    <input type="checkbox" name="selected_bursaries[]"
                                                        value="<?php echo e($bursary->id); ?>">
                                                </td>
                                                <td><?php echo e($startIndex + $index + 1); ?></td>
                                                <td><?php echo e($trimmed_fName); ?>

                                                    <?php echo e($trimmed_lName); ?>

                                                    (<?php echo e(ucfirst($bursary->gender)); ?>)
                                                </td>
                                                <td><?php echo e($trimmed_institution); ?> - <?php echo e($trimmed_adm); ?></td>
                                                <td><?php echo e($bursary->total_fees_payable); ?></td>
                                                <td><?php echo e($bursary->fee_balance); ?></td>
                                                <td><?php echo e($bursary->constituency->name); ?></td>
                                                <td><?php echo e($bursary->created_at->format('Y-m-d')); ?></td>

                                                <?php if($user->hasRole('super-admin')): ?>
                                                    <td>
                                                        <?php if($bursary->status == '0'): ?>
                                                            <span class="btn-sm btn btn-warning py-0">Pending</span>
                                                        <?php elseif($bursary->status == '1'): ?>
                                                            <span class="btn-sm btn btn-success py-0">Approved</span>
                                                        <?php else: ?>
                                                            <span class="btn-sm btn btn-danger py-0">Rejected</span>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php else: ?>
                                                    <td><span class="btn-sm btn btn-warning py-0">Pending</span></td>
                                                <?php endif; ?>

                                                <td class="d-flex">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view bursary')): ?>
                                                        <a href="#" class="btn-sm btn btn-info mx-1" title="View"
                                                            data-toggle="modal"
                                                            data-target="#view_bursary<?php echo e($bursary->id); ?>"><i
                                                                class="fas fa-eye"></i></a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit bursary')): ?>
                                                        <a href="<?php echo e(route('admin.edit.bursary', encrypt($bursary->id))); ?>"
                                                            class="btn-sm btn btn-warning" title="Update"><i
                                                                class="fas fa-edit"></i></a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete bursary')): ?>
                                                        <form class="mx-1"
                                                            onclick="return confirm('Are you sure you want to delete?')"
                                                            action="<?php echo e(route('admin.destroy.bursary', encrypt($bursary->id))); ?>"
                                                            method="POST" title="Delete">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button class="btn-sm btn btn-danger" type="submit"><i
                                                                    class="fas fa-trash"></i></button>
                                                        </form>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>

                                            <!--view bursary-->
                                            <div class="modal fade" id="view_bursary<?php echo e($bursary->id); ?>" tabindex="-1"
                                                role="dialog" aria-labelledby="myModalLabel" data-backdrop="static">
                                                <div class="modal-dialog modal-lg" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header px-3 py-2">
                                                            <h5 class="modal-title" id="myModalLabel">Name:
                                                                <?php echo e($bursary->first_name); ?> <?php echo e($bursary->last_name); ?>

                                                            </h5>
                                                            <div id="loadingMessage" class="pl-4">
                                                                <div class="loading-container">
                                                                    <strong>
                                                                        <i class="fas fa-spinner fa-spin"></i> &nbsp;
                                                                        Loading...
                                                                    </strong>
                                                                </div>
                                                            </div>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close" title="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body p-3">
                                                            <ul class="nav nav-tabs">
                                                                <li class="nav-item p-0">
                                                                    <a class="nav-link active"
                                                                        href="#personal_data<?php echo e($bursary->id); ?>"
                                                                        data-toggle="tab">Personal Details</a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a class="nav-link"
                                                                        href="#family_data<?php echo e($bursary->id); ?>"
                                                                        data-toggle="tab">Family Information</a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a class="nav-link"
                                                                        href="#address_data<?php echo e($bursary->id); ?>"
                                                                        data-toggle="tab">Address Information</a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a class="nav-link"
                                                                        href="#school_data<?php echo e($bursary->id); ?>"
                                                                        data-toggle="tab">School Details</a>
                                                                </li>

                                                                <li class="nav-item">
                                                                    <a class="nav-link"
                                                                        href="#attachments_data<?php echo e($bursary->id); ?>"
                                                                        data-toggle="tab">Key Attachments</a>
                                                                </li>
                                                            </ul>
                                                            <div class="tab-content">
                                                                
                                                                <div class="tab-pane active"
                                                                    id="personal_data<?php echo e($bursary->id); ?>">
                                                                    <div class="row mt-3">
                                                                        <div class="col-md-4 my-2">
                                                                            <label for="">First Name: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->first_name); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-2">
                                                                            <label for="">Last Name: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->last_name); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-2">
                                                                            <label for="">Gender: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->gender); ?>" readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-2">
                                                                            <label for="">ID/Passport no.:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->id_or_passport_no); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-2">
                                                                            <label for="">D.O.B: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e(\Carbon\Carbon::parse($bursary->date_of_birth)->format('Y-m-d')); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-2">
                                                                            <label for="">Telephone Number:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->telephone_number); ?>"
                                                                                readonly>
                                                                        </div>

                                                                    </div>

                                                                </div>
                                                                

                                                                
                                                                <div class="tab-pane"
                                                                    id="family_data<?php echo e($bursary->id); ?>">
                                                                    <div class="row mt-3">
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Parental Status: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->parental_status); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Number of
                                                                                Siblings: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->number_of_siblings); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Estimated Family
                                                                                Income: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->estimated_family_income); ?>"
                                                                                readonly>
                                                                        </div>
                                                                    </div>
                                                                    <h5 style="font-size: 16px" class="text-bold mt-2">
                                                                        Father's Information:</h5>
                                                                    <div class="row">
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">First Name:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->fathers_firstname); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Last Name:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->fathers_lastname); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Telephone Number:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->fathers_telephone_number); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Occupation:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->fathers_occupation); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Employment Type:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e(ucfirst($bursary->fathers_employment_type)); ?>"
                                                                                readonly>
                                                                        </div>

                                                                    </div>
                                                                    <h5 style="font-size: 16px" class="text-bold mt-2">
                                                                        Mother's Information:</h5>
                                                                    <div class="row">
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">First Name:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->mothers_firstname); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Last Name:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->mothers_lastname); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Telephone Number:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->mothers_telephone_number); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Occupation:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->mothers_occupation); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Employment Type:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e(ucfirst($bursary->mothers_employment_type)); ?>"
                                                                                readonly>
                                                                        </div>

                                                                    </div>

                                                                    <h5 style="font-size: 16px" class="text-bold mt-2">
                                                                        Guardian's Information:</h5>
                                                                    <div class="row">
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">First Name:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->guardians_firstname); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Last Name:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->guardians_lastname); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Telephone Number:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->guardians_telephone_number); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Occupation:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->guardians_occupation); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Employment Type:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e(ucfirst($bursary->guardians_employment_type)); ?>"
                                                                                readonly>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                                

                                                                
                                                                <div class="tab-pane"
                                                                    id="address_data<?php echo e($bursary->id); ?>">
                                                                    <div class="row mt-3">
                                                                        <div class="col-md-4 my-2">
                                                                            <label for="">County: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->county->name); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-2">
                                                                            <label for="">Constituency: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->constituency->name); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-2">
                                                                            <label for="">Ward: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->ward->name); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-2">
                                                                            <label for="">Location: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->location->name); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-2">
                                                                            <label for="">Sub location: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->sublocation->name); ?>"
                                                                                readonly>
                                                                        </div>

                                                                        <div class="col-md-4 my-2">
                                                                            <label for="">Polling Station: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->pollingstation->name); ?>"
                                                                                readonly>
                                                                        </div>

                                                                    </div>

                                                                </div>
                                                                

                                                                
                                                                <div class="tab-pane"
                                                                    id="school_data<?php echo e($bursary->id); ?>">
                                                                    <div class="row mt-3">
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">School Name: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->institution_name); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Admission/Registration
                                                                                no.: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->adm_or_reg_no); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Study Mode: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->mode_of_study); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Class/Year of
                                                                                Study: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->year_of_study); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Course:</label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->course_name); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Postal Address: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->instititution_postal_address); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Telephone Number: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->instititution_telephone_number); ?>"
                                                                                readonly>
                                                                        </div>

                                                                    </div>
                                                                    <h5 style="font-size: 16px" class="text-bold mt-2">
                                                                        Fees Payable:</h5>
                                                                    <div class="row">
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Total Fees
                                                                                Payable: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->total_fees_payable); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Fees Paid: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->total_fees_paid); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Fee Balance: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->fee_balance); ?>"
                                                                                readonly>
                                                                        </div>
                                                                    </div>

                                                                    <h5 style="font-size: 16px" class="text-bold mt-2">
                                                                        Account Details:</h5>
                                                                    <div class="row">
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Name of Bank: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->bank_name); ?>"
                                                                                readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Branch: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->branch); ?>" readonly>
                                                                        </div>
                                                                        <div class="col-md-4 my-1">
                                                                            <label for="">Account Number: <span
                                                                                    class="text-danger">*</span></label>
                                                                            <input type="text" class="form-control"
                                                                                value="<?php echo e($bursary->account_number); ?>"
                                                                                readonly>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                                

                                                                
                                                                <div class="tab-pane"
                                                                    id="attachments_data<?php echo e($bursary->id); ?>">
                                                                    <div class="row mt-3">
                                                                        <div class="col-md-4 p-2">
                                                                            <div class="attachment">
                                                                                <span
                                                                                    class="attachment-name">Transcipt/Report
                                                                                    form: <span
                                                                                        class="text-danger">*</span></span>
                                                                                <a href="<?php echo e(route('download.attachment', ['filename' => $bursary->transcript_report_form])); ?>"
                                                                                    class="download-link"
                                                                                    title="Download transcipt/report form">
                                                                                    <i class="fas fa-download"></i>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-4 p-2">
                                                                            <div class="attachment">
                                                                                <span
                                                                                    class="attachment-name">Parents/Guardian
                                                                                    ID: <span
                                                                                        class="text-danger">*</span></span>
                                                                                <a href="<?php echo e(route('download.attachment', ['filename' => $bursary->parents_or_guardian_id])); ?>"
                                                                                    class="download-link"
                                                                                    title="Download parents/guardian ID">
                                                                                    <i class="fas fa-download"></i>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                        <?php if($bursary->personal_id): ?>
                                                                            <div class="col-md-4 p-2">
                                                                                <div class="attachment">
                                                                                    <span class="attachment-name">Personal
                                                                                        ID/Passport:</span>
                                                                                    <a href="<?php echo e(route('download.attachment', ['filename' => $bursary->personal_id])); ?>"
                                                                                        class="download-link"
                                                                                        title="Download personal ID/passport">
                                                                                        <i class="fas fa-download"></i>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                        <?php else: ?>
                                                                            <div class="col-md-4 p-2">
                                                                                <div class="attachment">
                                                                                    <span class="attachment-name">Personal
                                                                                        ID/Passport: ---</span>

                                                                                </div>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                        <div class="col-md-4 p-2">
                                                                            <div class="attachment">
                                                                                <span class="attachment-name">Birth
                                                                                    Certificate: <span
                                                                                        class="text-danger">*</span></span>
                                                                                <a href="<?php echo e(route('download.attachment', ['filename' => $bursary->birth_certificate])); ?>"
                                                                                    class="download-link"
                                                                                    title="Download birth certificate">
                                                                                    <i class="fas fa-download"></i>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                        <?php if($bursary->school_id): ?>
                                                                            <div class="col-md-4 p-2">
                                                                                <div class="attachment">
                                                                                    <span class="attachment-name">School
                                                                                        ID:</span>
                                                                                    <a href="<?php echo e(route('download.attachment', ['filename' => $bursary->school_id])); ?>"
                                                                                        class="download-link"
                                                                                        title="Download school ID">
                                                                                        <i class="fas fa-download"></i>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                        <?php else: ?>
                                                                            <div class="col-md-4 p-2">
                                                                                <div class="attachment">
                                                                                    <span class="attachment-name">School
                                                                                        ID: ---</span>

                                                                                </div>
                                                                            </div>
                                                                        <?php endif; ?>

                                                                        <?php if($bursary->fathers_death_certificate): ?>
                                                                            <div class="col-md-4 p-2">
                                                                                <div class="attachment">
                                                                                    <span class="attachment-name">Father's
                                                                                        Death Certificate:</span>
                                                                                    <a href="<?php echo e(route('download.attachment', ['filename' => $bursary->fathers_death_certificate])); ?>"
                                                                                        class="download-link"
                                                                                        title="Download father's death certificate">
                                                                                        <i class="fas fa-download"></i>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                        <?php else: ?>
                                                                            <div class="col-md-4 p-2">
                                                                                <div class="attachment">
                                                                                    <span class="attachment-name">Father's
                                                                                        Death Certificate: ---</span>
                                                                                </div>
                                                                            </div>
                                                                        <?php endif; ?>

                                                                        <?php if($bursary->mothers_death_certificate): ?>
                                                                            <div class="col-md-4 p-2">
                                                                                <div class="attachment">
                                                                                    <span class="attachment-name">Mother's
                                                                                        Death Certificate:</span>
                                                                                    <a href="<?php echo e(route('download.attachment', ['filename' => $bursary->mothers_death_certificate])); ?>"
                                                                                        class="download-link"
                                                                                        title="Download mother's death certificate">
                                                                                        <i class="fas fa-download"></i>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                        <?php else: ?>
                                                                            <div class="col-md-4 p-2">
                                                                                <div class="attachment">
                                                                                    <span class="attachment-name">Mother's
                                                                                        Death Certificate: --- </span>
                                                                                </div>
                                                                            </div>
                                                                        <?php endif; ?>

                                                                        <div class="col-md-4 p-2">
                                                                            <div class="attachment">
                                                                                <span class="attachment-name">Current Fee
                                                                                    Structure: <span
                                                                                        class="text-danger">*</span></span>
                                                                                <a href="<?php echo e(route('download.attachment', ['filename' => $bursary->current_fee_structure])); ?>"
                                                                                    class="download-link"
                                                                                    title="Download current fee structure">
                                                                                    <i class="fas fa-download"></i>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-4 p-2">
                                                                            <div class="attachment">
                                                                                <span class="attachment-name">Admission
                                                                                    Letter: <span
                                                                                        class="text-danger">*</span></span>
                                                                                <a href="<?php echo e(route('download.attachment', ['filename' => $bursary->admission_letter])); ?>"
                                                                                    class="download-link"
                                                                                    title="Download admission letter">
                                                                                    <i class="fas fa-download"></i>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                                

                                                            </div>
                                                        </div>
                                                        <div class="modal-footer mb-2">
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('approve bursary')): ?>
                                                                <button type="button" id="approval_btn"
                                                                    class="btn-sm btn btn-success"
                                                                    onclick="approveApplication(<?php echo e($bursary->id); ?>)">Approve</button>
                                                            <?php endif; ?>
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reject bursary')): ?>
                                                                <button type="button" id="rejectral_btn"
                                                                    class="btn-sm btn btn-danger"
                                                                    onclick="rejectApplication(<?php echo e($bursary->id); ?>)">Reject</button>
                                                            <?php endif; ?>

                                                            <button type="button"
                                                                class="btn-sm btn btn-default bg-secondary"
                                                                data-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/view bursary-->

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td class="fas fa-folder-open"> No Pending Applications</td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        <?php endif; ?>

                                    </tbody>
                                    <tfoot>
                                        <tr style="white-space: nowrap;">
                                            <th>*</th>
                                            <th>#</th>
                                            <th>Applicant info.</th>
                                            <th>Institution info.</th>
                                            <th>Total Fees</th>
                                            <th>Balance</th>
                                            <th>Constituency</th>
                                            <th>Date Applied</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                </table>

                                <div class="row">
                                    <div class="col-md-12 pt-2">
                                        <?php if($bursaries->hasPages()): ?>
                                            <div class="d-flex justify-content-end">
                                                <nav aria-label="Page navigation">
                                                    <ul class="pagination">
                                                        
                                                        <li
                                                            class="page-item <?php echo e($bursaries->onFirstPage() ? 'disabled' : ''); ?>">
                                                            <a class="page-link"
                                                                href="<?php echo e($bursaries->previousPageUrl()); ?>"
                                                                aria-label="Previous">
                                                                <span aria-hidden="true">&laquo;</span>
                                                            </a>
                                                        </li>
                                                        
                                                        <?php $__currentLoopData = $bursaries->getUrlRange(1, $bursaries->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li
                                                                class="page-item <?php echo e($bursaries->currentPage() === $page ? 'active' : ''); ?>">
                                                                <a class="page-link"
                                                                    href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        
                                                        <li
                                                            class="page-item <?php echo e(!$bursaries->hasMorePages() ? 'disabled' : ''); ?>">
                                                            <a class="page-link" href="<?php echo e($bursaries->nextPageUrl()); ?>"
                                                                aria-label="Next">
                                                                <span aria-hidden="true">&raquo;</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>
                                        <?php endif; ?>

                                    </div>
                                </div>

                            </div>
                            <!-- /.card-body -->

                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->

    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(url('Admin/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(url('Admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(url('Admin/dist/js/adminlte.min.js')); ?>"></script>
    <script>
        var hasApprovePermission =
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('approve bursary')): ?>
                true
            <?php else: ?>
                false
            <?php endif; ?> ;
        var hasRejectPermission =
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reject bursary')): ?>
                true
            <?php else: ?>
                false
            <?php endif; ?> ;
        var bulkActionRoute = '<?php echo e(route('bulk.actions')); ?>';
    </script>
    <!-- Custom js -->
    <script src="<?php echo e(url('Admin/js/bursary/index.js')); ?>"></script>
    <!-- Include DataTables JavaScript -->
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script>
        function approveApplication(bursaryId) {
            if (confirm("Are you sure you want to approve this application?")) {
                $('#loadingMessage').show();
                $('#approval_btn').prop('disabled', true);
                $('#rejectral_btn').prop('disabled', true);
                $.ajax({
                    url: '<?php echo e(route('bursary.updateApprovedStatus')); ?>',
                    type: 'POST',
                    data: {
                        bursaryId: bursaryId
                    },
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(response) {
                        $('#approval_btn').prop('disabled', false);
                        $('#rejectral_btn').prop('disabled', false);
                        window.location.href = response.url;
                    },
                    error: function(xhr, status, error) {
                        $('#approval_btn').prop('disabled', false);
                        $('#rejectral_btn').prop('disabled', false);
                    }
                });
            } else {
                return false; // Abort the AJAX request
            }
        }

        function rejectApplication(bursaryId) {
            if (confirm("Are you sure you want to reject this application?")) {
                $('#loadingMessage').show();
                $('#rejectral_btn').prop('disabled', true);
                $('#approval_btn').prop('disabled', true);

                $.ajax({
                    url: '<?php echo e(route('bursary.updateRejectedStatus')); ?>',
                    type: 'POST',
                    data: {
                        bursaryId: bursaryId
                    },
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(response) {
                        $('#rejectral_btn').prop('disabled', false);
                        $('#approval_btn').prop('disabled', false);
                        window.location.href = response.url;
                    },
                    error: function(xhr, status, error) {
                        $('#rejectral_btn').prop('disabled', false);
                        $('#approval_btn').prop('disabled', false);
                    }
                });

            } else {
                return false; // Abort the AJAX request
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SoftwaresKe/Bursary/bursary/resources/views/applicant/bursary/index.blade.php ENDPATH**/ ?>