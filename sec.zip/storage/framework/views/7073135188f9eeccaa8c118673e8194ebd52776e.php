<?php $__env->startSection('title'); ?>
    Staff: <?php echo e($user->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/fontawesome-free/css/all.min.css')); ?>">

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/dist/css/adminlte.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(url('Admin/css/main.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <h4>Email: <?php echo e($user->email); ?></h4>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">
                                <a href="<?php echo e(route('staff.index')); ?>">Staffs</a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo e($user->email); ?></li>
                        </ol>
                    </div>
                </div>

            </div><!-- /.container-fluid -->

        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit staff','delete staff'])): ?>
                            <div class="card-header d-flex">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit staff')): ?>
                                
                                <a href="<?php echo e(route('staff.edit', encrypt($user->id))); ?>" class="btn-sm btn btn-primary" title="Update"><i class="fas fa-edit"></i> Update</a>

                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete staff')): ?>
                                <form class="mx-1"
                                    onclick="return confirm('Are you sure you want to delete <?php echo e($user->name); ?>?')"
                                    action="<?php echo e(route('staff.destroy', $user->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button class="btn-sm btn btn-danger" type="submit"><i
                                            class="fas fa-trash"></i> Delete</button>
                                </form>
                                <?php endif; ?>

                            </div>
                            <?php endif; ?>
                            <!-- /.card-header -->
                            <div class="card-body p-0">
                                <table class="table table-striped">
                                    <thead>

                                    </thead>
                                    <tbody>

                                        <tr>
                                            <td style="width: 30%"><b>Username</b> </td>
                                            <td><?php echo e($user->name); ?></td>
                                        </tr>
                                        <tr>
                                            <td style="width: 30%"><b>Email Address</b> </td>
                                            <td><a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></td>
                                        </tr>
                                        <tr>
                                            <td style="width: 30%"><b>Date Created</b> </td>
                                            <td><?php echo e($user->created_at); ?></td>
                                            
                                        </tr>
                                        <tr>
                                            <td style="width: 30%"><b>Last Updated</b> </td>
                                            <td><?php echo e($user->updated_at); ?></td>
                                        </tr>
                                        <tr>
                                            <td style="width: 30%"><b>Role</b> </td>
                                            <td>
                                                <?php $__empty_1 = true; $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <?php echo e($role->name); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage bursary')): ?>
                                       
                                        <tr>
                                            <td style="width: 30%"><b>Tasks Attended</b> </td>
                                            <td>
                                                <a href="<?php echo e(route('staff.view.approved.applications',encrypt($user->id))); ?>">
                                                <span class="btn-sm btn btn-success py-1">
                                                    Approved <div class="circle_approved_num"><span class="appr_rej_number"><?php echo e($attendedApprovedBursaries); ?></span></div>
                                                </span>
                                                </a>
                                                <a href="<?php echo e(route('staff.view.rejected.applications',encrypt($user->id))); ?>">
                                                <span class="btn-sm btn btn-danger py-1">
                                                    Rejected<div class="circle_rejected_num"><span class="appr_rej_number"><?php echo e($attendedRejectedBursaries); ?></span></div>
                                                </span>
                                                </a>
                                            </td>

                                        </tr>
                                        <?php endif; ?>

                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(url('Admin/plugins/jquery/jquery.min.js')); ?>"></script>

    <!-- Bootstrap 4 -->
    <script src="<?php echo e(url('Admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(url('Admin/dist/js/adminlte.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/Backup/First/bursary/resources/views/staff/staff_users/show.blade.php ENDPATH**/ ?>