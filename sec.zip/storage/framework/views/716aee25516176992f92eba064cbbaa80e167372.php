<?php $__env->startComponent('mail::message'); ?>
    <p>Congratulations <?php echo e($user->name); ?></p>
    <p>Congratulations, your bursary application for academic year <?php echo e($year); ?> has been approved.
        <?php echo e($institution); ?> will receive your funds.</p>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/Backup/First/bursary/resources/views/admin/customEmail/bursary-approved.blade.php ENDPATH**/ ?>