<?php $__env->startComponent('mail::message'); ?>
    <p>Congratulations <?php echo e($user->name); ?></p>
    <p>Congratulations, you have successfully applied the bursary application for year academic year <?php echo e($year); ?>. Kindly wait us we check your application.</p>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/Backup/First/bursary/resources/views/admin/customEmail/bursary-successful-application.blade.php ENDPATH**/ ?>