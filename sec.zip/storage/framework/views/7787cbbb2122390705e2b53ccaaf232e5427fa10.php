<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/fontawesome-free/css/all.min.css')); ?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <!-- JQVMap -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/jqvmap/jqvmap.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/dist/css/adminlte.min.css')); ?>">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/daterangepicker/daterangepicker.css')); ?>">
    <!-- summernote -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/summernote/summernote-bs4.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(url('Admin/css/main.css')); ?>">
<?php $__env->stopSection(); ?>

<?php
    $users = App\Models\User::all(); // Retrieve all users from the database
    
?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Dashboard</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->

        </div>
        <!-- /.content-header -->

        <div class="row px-3">
            <div class="col-sm-12">
                <?php echo $__env->make('layouts.flash-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

        </div>
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-info">
                            <div class="inner">
                                <h3>
                                    <?php if(Gate::check('manage user')): ?>
                                        <?php if(count($users) > 0): ?>
                                            <?php echo e(count($users)); ?>

                                        <?php else: ?>
                                            0
                                        <?php endif; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </h3>
                                <span class="info-box-text">Total Users</span>
                            </div>
                            <div class="icon">
                                <i class="fas fa-user-secret"></i>
                            </div>
                            <a href="<?php echo e(route('user.index')); ?>" class="small-box-footer">More info <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-primary">
                            <div class="inner">
                                <h3>
                                    <?php if(Gate::check('manage staff')): ?>
                                        <?php if($staffCount > 0): ?>
                                            <?php echo e($staffCount); ?>

                                        <?php else: ?>
                                            0
                                        <?php endif; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </h3>
                                <span class="info-box-text">Total Staffs</span>

                            </div>
                            <div class="icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <a href="<?php echo e(route('staff.index')); ?>" class="small-box-footer">More info <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>

                    
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-info">
                            <div class="inner">
                                <h3>
                                    <?php if(Gate::check('manage role')): ?>
                                        <?php if($totalRolesCount > 0): ?>
                                            <?php echo e($totalRolesCount); ?>

                                        <?php else: ?>
                                            0
                                        <?php endif; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </h3>
                                <span class="info-box-text">Total Roles</span>
                            </div>
                            <div class="icon">
                                <i class="fas fa-tasks"></i>
                            </div>
                            <a href="<?php echo e(route('role.index')); ?>" class="small-box-footer">More info <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <!-- ./col -->
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-primary">
                            <div class="inner">
                                <h3>
                                    <?php if(Gate::check('manage bursary')): ?>
                                        <?php if($bursaryApplicationsCount > 0): ?>
                                            <?php echo e($bursaryApplicationsCount); ?>

                                        <?php else: ?>
                                            0
                                        <?php endif; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </h3>
                                <span class="info-box-text">Total Applications</span>
                            </div>
                            <div class="icon">
                                <i class="fas fa-hand-holding"></i>
                            </div>
                            <a href="<?php echo e(route('bursary.index')); ?>" class="small-box-footer">More info <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>

                </div>

                <div class="row">
                    <!-- ./col -->
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-success">
                            <div class="inner">
                                <h3>
                                    <?php if(Gate::check('manage bursary')): ?>
                                        <?php if($approvedbursaryApplicationsCount > 0): ?>
                                            <?php echo e($approvedbursaryApplicationsCount); ?>

                                        <?php else: ?>
                                            0
                                        <?php endif; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </h3>
                                <span class="info-box-text">Approved Applications</span>
                            </div>
                            <div class="icon">
                                <i class="fas fa-thumbs-up"></i>
                            </div>
                            <a href="<?php echo e(route('approved.applications')); ?>" class="small-box-footer">More info <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->

                    <!-- ./col -->
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-warning">
                            <div class="inner">
                                <h3>
                                    <?php if(Gate::check('manage bursary')): ?>
                                        <?php if($pendingbursaryApplicationsCount > 0): ?>
                                            <?php echo e($pendingbursaryApplicationsCount); ?>

                                        <?php else: ?>
                                            0
                                        <?php endif; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </h3>
                                <span class="info-box-text">Pending Applications</span>
                            </div>
                            <div class="icon">
                                <i class="far fa-circle"></i>
                            </div>
                            <a href="<?php echo e(route('bursary.index')); ?>" class="small-box-footer">More info <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->

                    <!-- ./col -->
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-danger">
                            <div class="inner">
                                <h3>
                                    <?php if(Gate::check('manage bursary')): ?>
                                        <?php if($rejectedbursaryApplicationsCount > 0): ?>
                                            <?php echo e($rejectedbursaryApplicationsCount); ?>

                                        <?php else: ?>
                                            0
                                        <?php endif; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </h3>
                                <span class="info-box-text">Rejected Applications</span>
                            </div>
                            <div class="icon">
                                <i class="fas fa-thumbs-down"></i>
                            </div>
                            <a href="<?php echo e(route('rejected.applications')); ?>" class="small-box-footer">More info <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-info">
                            <div class="inner">
                                <h3>
                                    <?php if(Gate::check('manage location')): ?>
                                        <?php if($countiesCount > 0): ?>
                                            <?php echo e($countiesCount); ?>

                                        <?php else: ?>
                                            0
                                        <?php endif; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </h3>
                                <span class="info-box-text">Counties</span>

                            </div>
                            <div class="icon">
                                <i class="ion ion-location"></i>

                            </div>
                            <a href="<?php echo e(route('county.index')); ?>" class="small-box-footer">More info <i
                                    class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>

                </div>
                
                <!-- Main row -->
                <div class="row">
                    <!-- Left col -->
                    <section class="col-lg-9 connectedSortable bursary_graph_display">
                        <!-- Custom tabs (Charts with tabs)-->
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <i class="fas fa-chart-bar mr-1"></i>
                                    Last Ten Financial Years
                                </h3>
                                <div class="card-tools">
                                    <ul class="nav nav-pills ml-auto">
                                        <li class="nav-item">
                                            <a class="nav-link active" href="#approved_chart_area"
                                                data-toggle="tab">Approved</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#rejected_chart_area"
                                                data-toggle="tab">Rejected</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="#pending_chart_area" data-toggle="tab">Pending</a>
                                        </li>
                                    </ul>
                                </div>
                            </div><!-- /.card-header -->
                            <div class="card-body bursary_graph_display_body">
                                <div class="tab-content p-0">
                                    <?php if(Gate::check('manage bursary')): ?>
                                    <div class="chart tab-pane active" id="approved_chart_area"
                                        style="position: relative; height: auto;">
                                        
                                        <div style="width: 100%">
                                            <canvas id="approved_chart"></canvas>
                                        </div>
                                    </div>

                                    <div class="chart tab-pane" id="rejected_chart_area"
                                        style="position: relative; height: auto;">
                                        
                                        <div style="width: 100%">
                                            <canvas id="rejected_chart"></canvas>
                                        </div>
                                    </div>

                                    <div class="chart tab-pane" id="pending_chart_area"
                                        style="position: relative; height: auto;">
                                        
                                        <div style="width: 100%">
                                            <canvas id="pending_chart"></canvas>
                                        </div>
                                    </div>

                                    <?php endif; ?>

                                </div>
                            </div><!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                        

                    </section>
                    
                    <!-- /.Left col -->
                    <div class="col-md-3">
                        <!-- Info Boxes Style 2 -->
                        <div class="info-box mb-3 bg-success">
                            <span class="info-box-icon"><i class="ion ion-location"></i></span>

                            <div class="info-box-content">
                                <span class="info-box-text">Constituencies</span>
                                <span class="info-box-number">
                                    <?php if(Gate::check('manage location')): ?>
                                        <?php if($constituenciesCount > 0): ?>
                                            <?php echo e($constituenciesCount); ?>

                                        <?php else: ?>
                                            0
                                        <?php endif; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </span>
                            </div>
                            <!-- /.info-box-content -->
                        </div>
                        <!-- /.info-box -->
                        <div class="info-box mb-3 bg-info">
                            <span class="info-box-icon"><i class="ion ion-location"></i></span>

                            <div class="info-box-content">
                                <span class="info-box-text">Wards</span>
                                <span class="info-box-number">
                                    <?php if(Gate::check('manage location')): ?>
                                        <?php if($wardsCount > 0): ?>
                                            <?php echo e($wardsCount); ?>

                                        <?php else: ?>
                                            0
                                        <?php endif; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </span>
                            </div>
                            <!-- /.info-box-content -->
                        </div>
                        <!-- /.info-box -->
                        <div class="info-box mb-3 bg-primary">
                            <span class="info-box-icon"><i class="ion ion-location"></i></span>

                            <div class="info-box-content">
                                <span class="info-box-text">Locations</span>
                                <span class="info-box-number">
                                    <?php if(Gate::check('manage location')): ?>
                                        <?php if($locationsCount > 0): ?>
                                            <?php echo e($locationsCount); ?>

                                        <?php else: ?>
                                            0
                                        <?php endif; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </span>
                            </div>
                            <!-- /.info-box-content -->
                        </div>
                        <!-- /.info-box -->

                        <div class="info-box mb-3 bg-olive">
                            <span class="info-box-icon"><i class="ion ion-location"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">Sub-Locations</span>
                                <span class="info-box-number">
                                    <?php if(Gate::check('manage location')): ?>
                                        <?php if($sublocationsCount > 0): ?>
                                            <?php echo e($sublocationsCount); ?>

                                        <?php else: ?>
                                            0
                                        <?php endif; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </span>
                            </div>
                        </div>
                        <div class="info-box mb-3 bg-danger">
                            <span class="info-box-icon"><i class="ion ion-location"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">Polling Stations</span>
                                <span class="info-box-number">
                                    <?php if(Gate::check('manage location')): ?>
                                        <?php if($pollingstationsCount > 0): ?>
                                            <?php echo e($pollingstationsCount); ?>

                                        <?php else: ?>
                                            0
                                        <?php endif; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </span>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.row (main row) -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(url('Admin/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- jQuery UI 1.11.4 -->

    <script src="<?php echo e(url('Admin/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
        $.widget.bridge('uibutton', $.ui.button)
    </script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(url('Admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- ChartJS -->
    <script src="<?php echo e(url('Admin/plugins/chart.js/Chart.min.js')); ?>"></script>
    <!-- Sparkline -->
    
    <script src="<?php echo e(url('Admin/plugins/sparklines/sparkline.js')); ?>"></script>
    <!-- JQVMap -->
    <script src="<?php echo e(url('Admin/plugins/jqvmap/jquery.vmap.min.js')); ?>"></script>
    <script src="<?php echo e(url('Admin/plugins/jqvmap/maps/jquery.vmap.usa.js')); ?>"></script>
    <!-- jQuery Knob Chart -->
    <script src="<?php echo e(url('Admin/plugins/jquery-knob/jquery.knob.min.js')); ?>"></script>
    <!-- daterangepicker -->
    <script src="<?php echo e(url('Admin/plugins/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(url('Admin/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
    <!-- Tempusdominus Bootstrap 4 -->
    <script src="<?php echo e(url('Admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
    <!-- Summernote -->
    <script src="<?php echo e(url('Admin/plugins/summernote/summernote-bs4.min.js')); ?>"></script>
    <!-- overlayScrollbars -->
    <script src="<?php echo e(url('Admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(url('Admin/dist/js/adminlte.js')); ?>"></script>

    <script>
        var totalApplications = <?php echo json_encode($totalApplications, 15, 512) ?>;
        // approved
        var approvalPercentages = <?php echo json_encode($approvalPercentages, 15, 512) ?>;
        // rejected
        var rejectralPercentages = <?php echo json_encode($rejectralPercentages, 15, 512) ?>;
        // pending
        var pendralPercentages = <?php echo json_encode($pendralPercentages, 15, 512) ?>;
    </script>
    <!-- Custom js -->
    <script src="<?php echo e(url('Admin/js/dashboard/admin/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/Backup/First/bursary/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>