[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /var/www/html/SoftwaresKe/Bursary/bursary/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>