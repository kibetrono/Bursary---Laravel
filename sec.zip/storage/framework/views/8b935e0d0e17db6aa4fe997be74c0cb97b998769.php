<footer class="main-footer">

    <?php if(isset($settingsfields['footer_text'])): ?>
        <strong><?php echo e($settingsfields['footer_text']); ?></strong>
    <?php else: ?>
        <strong>Footer text</strong>
    <?php endif; ?>

</footer>
<?php /**PATH /var/www/html/SoftwaresKe/Bursary/bursary/resources/views/layouts/footer.blade.php ENDPATH**/ ?>