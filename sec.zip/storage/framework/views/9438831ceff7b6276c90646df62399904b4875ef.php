<?php $__env->startComponent('mail::message'); ?>
    <p><?php echo e($body); ?> </p>
    <?php $__env->startComponent('mail::button', ['url'=>$url]); ?>
        Click Here to navigate back
    <?php echo $__env->renderComponent(); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/Backup/First/bursary/resources/views/admin/customEmail/test-configuration.blade.php ENDPATH**/ ?>