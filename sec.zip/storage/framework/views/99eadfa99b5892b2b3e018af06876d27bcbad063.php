<?php $__env->startComponent('mail::message'); ?>
    Hello <?php echo e($user->name); ?>,

    We sincerely regret to inform you that your bursary application for the academic year <?php echo e($year); ?> was not successful. After careful evaluation, it was determined that your application did not meet all the necessary requirements for consideration.

    Please be aware that the selection process is highly competitive, and we receive numerous applications each year. Although your application was not successful this time, we encourage you to try again in the future and explore other available opportunities for financial aid.

    Thank you for your interest in our bursary program, and we appreciate the effort you put into your application. We wish you the best in your academic pursuits and hope that you find success in your educational journey.

    Best regards,
    The <?php echo e(config('app.name')); ?> Team

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/SoftwaresKe/Bursary/bursary/resources/views/admin/customEmail/bursary-reject.blade.php ENDPATH**/ ?>