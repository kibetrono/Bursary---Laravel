<?php $__env->startComponent('mail::message'); ?>
    <h3>Hello, <?php echo e($user->name); ?></h3>
    <p>Welcome to our website. Thank you for signing up!</p>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/Backup/First/bursary/resources/views/admin/customEmail/welcome.blade.php ENDPATH**/ ?>