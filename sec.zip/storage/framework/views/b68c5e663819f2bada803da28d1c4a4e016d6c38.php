<?php echo e($slot); ?>

<?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/Backup/First/bursary/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>