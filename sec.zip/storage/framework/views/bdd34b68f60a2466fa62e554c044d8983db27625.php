<?php $__env->startSection('title'); ?>
    Application Periods
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/fontawesome-free/css/all.min.css')); ?>">

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/dist/css/adminlte.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php
$startIndex = ($application_periods->currentPage() - 1) * $application_periods->perPage();
?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Application Periods</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Application Periods</li>
                        </ol>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <?php echo $__env->make('layouts.flash-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                </div>
            </div><!-- /.container-fluid -->

        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">

                    <!-- /.col -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-info">
                                <h3 class="card-title">Application Periods </h3>
                                <div class="card-tools">
                                    
                                </div>
                            </div>

                            <!-- /.card-header -->
                            <div class="card-body table-responsive p-1">
                                <table class="table table-hover text-nowrap table-bordered">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Finacial Year</th>
                                            <th>Application Period From</th>
                                            <th>Application Period To</th>
                                            <th>Date created</th>
                                            <th>Date updated</th>
                                            <th>Status</th>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['update application period', 'delete application period'])): ?>
                                            <th>Action</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $application_periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$application_period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($startIndex + $index + 1); ?></td>
                                                <td><?php echo e($application_period->financial_year); ?></td>
                                                <td><?php echo e(\Carbon\Carbon::parse($application_period->period_from)->format('Y-m-d')); ?>

                                                </td>
                                                <td><?php echo e(\Carbon\Carbon::parse($application_period->period_to)->format('Y-m-d')); ?>

                                                </td>
                                                <td><?php echo e($application_period->created_at->format('Y-m-d')); ?></td>
                                                <td><?php echo e($application_period->updated_at->format('Y-m-d')); ?></td>
                                                <td>
                                                    <?php if($application_period->status == '0'): ?>
                                                        <span class="p-1 btn-sm btn btn-secondary">Inactive</span>
                                                    <?php else: ?>
                                                        <span class="p-1 btn-sm btn btn-success">Active</span>
                                                    <?php endif; ?>
                                                </td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['update application period', 'delete application period'])): ?>

                                                <td class="d-flex">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update application period')): ?>
                                                    <a href="<?php echo e(route('application-period.edit', encrypt($application_period->id))); ?>"
                                                        class="btn-sm btn btn-warning mx-1" title="Update"><i
                                                            class="fas fa-edit"></i></a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete application period')): ?>
                                                    <form class="mx-1"
                                                        onclick="return confirm('Are you sure you want to delete <?php echo e($application_period->name); ?>?')"
                                                        action="<?php echo e(route('application-period.destroy', encrypt($application_period->id))); ?>"
                                                        method="POST" title="Delete">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>

                                                        <button class="btn-sm btn btn-danger" type="submit"><i
                                                                class="fas fa-trash"></i></button>
                                                    </form>
                                                    <?php endif; ?>
                                                </td>
                                                <?php endif; ?>
                                            </tr>


                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td class="fas fa-folder-open"> No Settings Applied</td>
                                                <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            </tr>
                                        <?php endif; ?>


                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>

                                        </tr>
                                    </tfoot>
                                </table>
                                <div class="row">
                                    <div class="col-md-12 pt-2">
                                        <?php if($application_periods->hasPages()): ?>
                                            <div class="d-flex justify-content-end">
                                                <nav aria-label="Page navigation">
                                                    <ul class="pagination">
                                                        
                                                        <li
                                                            class="page-item <?php echo e($application_periods->onFirstPage() ? 'disabled' : ''); ?>">
                                                            <a class="page-link"
                                                                href="<?php echo e($application_periods->previousPageUrl()); ?>"
                                                                aria-label="Previous">
                                                                <span aria-hidden="true">&laquo;</span>
                                                            </a>
                                                        </li>

                                                        
                                                        <?php $__currentLoopData = $application_periods->getUrlRange(1, $application_periods->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li
                                                                class="page-item <?php echo e($application_periods->currentPage() === $page ? 'active' : ''); ?>">
                                                                <a class="page-link"
                                                                    href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        
                                                        <li
                                                            class="page-item <?php echo e(!$application_periods->hasMorePages() ? 'disabled' : ''); ?>">
                                                            <a class="page-link" href="<?php echo e($application_periods->nextPageUrl()); ?>"
                                                                aria-label="Next">
                                                                <span aria-hidden="true">&raquo;</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->


    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(url('Admin/plugins/jquery/jquery.min.js')); ?>"></script>

    <!-- Bootstrap 4 -->
    <script src="<?php echo e(url('Admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(url('Admin/dist/js/adminlte.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/Backup/First/bursary/resources/views/admin/application-period/index.blade.php ENDPATH**/ ?>