<?php $__env->startSection('title'); ?>
    Bursary Application History
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/fontawesome-free/css/all.min.css')); ?>">

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/dist/css/adminlte.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php
$startIndex = ($bursaries->currentPage() - 1) * $bursaries->perPage();
?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>History - <?php echo e(Auth::user()->email); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">History</li>
                        </ol>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <?php echo $__env->make('layouts.flash-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                </div>
            </div><!-- /.container-fluid -->

        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">

                    <!-- /.col -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-info">
                                <h3 class="card-title">Bursary Application History </h3>
                                <div class="card-tools">
                                    
                                </div>
                            </div>

                            <!-- /.card-header -->
                            <div class="card-header">
                                

                                <div class="card-tools my-1">
                                    
                                </div>

                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive p-1">
                                <table class="table table-hover text-nowrap table-bordered">
                                    <thead>
                                        <tr> 
                                            <th style="width:5%">#</th>
                                            <th style="width:12%">First Name</th>
                                            <th style="width:12%">Last Name</th>
                                            <th style="width:20%">School</th>
                                            <th style="width:10%">Fees Paid</th>
                                            <th style="width:10%">Balance</th>
                                            <th style="width:10%">Date applied</th>
                                            <th style="width:10%">Date updated</th>
                                            <th style="width:auto">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $bursaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$bursary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php
                                            $trimmed_school = strlen($bursary->institution_name) > 20 ? substr($bursary->institution_name, 0, 20) . '...' : $bursary->institution_name;
                                            $trimmed_fName = strlen($bursary->first_name) > 15 ? substr($bursary->first_name, 0, 15) . '...' : $bursary->first_name;
                                            $trimmed_lName = strlen($bursary->last_name) > 15 ? substr($bursary->last_name, 0, 15) . '...' : $bursary->last_name;
                                        ?>
                                            <tr>
                                                <td><?php echo e($startIndex + $index + 1); ?></td>
                                                <td><?php echo e($trimmed_fName); ?></td>
                                                <td><?php echo e($trimmed_lName); ?></td>
                                                <td><?php echo e($trimmed_school); ?></td>

                                                <td><?php echo e($bursary->total_fees_paid); ?></td>
                                                <td><?php echo e($bursary->fee_balance); ?></td>
                                                <td><?php echo e($bursary->created_at->format('Y-m-d')); ?></td>
                                                <td><?php echo e($bursary->updated_at->format('Y-m-d')); ?></td>
                                                <td>
                                                    <?php if($bursary->status == '0'): ?>
                                                        <span class="btn-sm btn btn-warning">Pending</span>
                                                    <?php elseif($bursary->status == '1'): ?>
                                                        <span class="btn-sm btn btn-success">Approved</span>
                                                    <?php else: ?>
                                                        <span class="btn-sm btn btn-danger">Rejected</span>
                                                    <?php endif; ?>
                                                </td>

                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td class="fas fa-folder-open"> Empty Application History</td>
                                        
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        <?php endif; ?>

                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>

                                        </tr>
                                    </tfoot>
                                </table>

                                <div class="row">
                                    <div class="col-md-12 pt-2">
                                        <?php if($bursaries->hasPages()): ?>
                                            <div class="d-flex justify-content-end">
                                                <nav aria-label="Page navigation">
                                                    <ul class="pagination">
                                                        
                                                        <li
                                                            class="page-item <?php echo e($bursaries->onFirstPage() ? 'disabled' : ''); ?>">
                                                            <a class="page-link"
                                                                href="<?php echo e($bursaries->previousPageUrl()); ?>"
                                                                aria-label="Previous">
                                                                <span aria-hidden="true">&laquo;</span>
                                                            </a>
                                                        </li>

                                                        
                                                        <?php $__currentLoopData = $bursaries->getUrlRange(1, $bursaries->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li
                                                                class="page-item <?php echo e($bursaries->currentPage() === $page ? 'active' : ''); ?>">
                                                                <a class="page-link"
                                                                    href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        
                                                        <li
                                                            class="page-item <?php echo e(!$bursaries->hasMorePages() ? 'disabled' : ''); ?>">
                                                            <a class="page-link" href="<?php echo e($bursaries->nextPageUrl()); ?>"
                                                                aria-label="Next">
                                                                <span aria-hidden="true">&raquo;</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->

    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(url('Admin/plugins/jquery/jquery.min.js')); ?>"></script>

    <!-- Bootstrap 4 -->
    <script src="<?php echo e(url('Admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(url('Admin/dist/js/adminlte.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SoftwaresKe/Bursary/bursary/resources/views/applicant/bursary/history.blade.php ENDPATH**/ ?>