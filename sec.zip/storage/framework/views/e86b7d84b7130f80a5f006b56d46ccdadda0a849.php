<?php $__env->startComponent('mail::message'); ?>
    <p>Hi <?php echo e($name); ?>,</p>
    <p>Welcome to our department.You have been assigned a <?php echo e($role->name); ?> role. Kindly adhere to all the rules required as a <?php echo e($role->name); ?></p>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/Backup/First/bursary/resources/views/admin/customEmail/create-user.blade.php ENDPATH**/ ?>