<?php $__env->startComponent('mail::message'); ?>
    
    <h3>Hello, <?php echo e($user->name); ?></h3>
    Welcome to our website. Thank you for signing up!

    
    We are thrilled to have you as part of our community. Here are some important details about your account:

    - Email Address: <?php echo e($user->email); ?>

    - Account Creation Date: <?php echo e($user->created_at->format('M d, Y')); ?>


    
    Get started by logging into your account and exploring all the exciting features we have to offer. If you have any
    questions or need assistance, feel free to reach out to our support team at info@softwareske.com .

    
    Best regards,
    The <?php echo e(config('app.name')); ?> Team
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/SoftwaresKe/Bursary/bursary/resources/views/admin/customEmail/welcome.blade.php ENDPATH**/ ?>