<?php $__env->startSection('title'); ?>
    Bursary Application Lists
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/fontawesome-free/css/all.min.css')); ?>">

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/dist/css/adminlte.min.css')); ?>">

    <!-- Include DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">

    
    <link rel="stylesheet" href="<?php echo e(url('Admin/css/main.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(url('Admin/plugins/jquery/jquery.min.js')); ?>"></script>

    <!-- Bootstrap 4 -->
    <script src="<?php echo e(url('Admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(url('Admin/dist/js/adminlte.min.js')); ?>"></script>

    <!-- AdminLTE for demo purposes -->
    <script src="<?php echo e(url('Admin/dist/js/demo.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            $('#users-table').DataTable({
                "paging": true,
                "pageLength": 10, // Show 10 entries per page
                "lengthMenu": [
                    [5, 10, 25, 50, 100, -1],
                    [5, 10, 25, 50, 100, "All"]
                ],
                // Add more customization options as needed
            });
        });
    </script>

    <!-- Include DataTables JavaScript -->
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/bursary/resources/views/admin/users/user_modal.blade.php ENDPATH**/ ?>