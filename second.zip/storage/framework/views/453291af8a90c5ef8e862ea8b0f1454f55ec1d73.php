<div class="modal fade" id="userModal<?php echo e($bursary->id); ?>" tabindex="-1" role="dialog" aria-labelledby="userModal<?php echo e($bursary->id); ?>Label" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="userModal<?php echo e($bursary->id); ?>Label">User Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="step-content">
                    <form id="userForm">
                        <div class="step-pane active" id="step1">
                            <!-- Step 1 form fields -->
                            <button type="button" class="btn btn-primary next-step">Next</button>
                        </div>

                        <div class="step-pane" id="step2">
                            <!-- Step 2 form fields -->
                            <button type="button" class="btn btn-secondary prev-step">Previous</button>
                            <button type="button" class="btn btn-primary next-step">Next</button>
                        </div>

                        <div class="step-pane" id="step3">
                            <!-- Step 3 form fields -->
                            <button type="button" class="btn btn-secondary prev-step">Previous</button>
                            <button type="button" class="btn btn-success">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        var currentStep = 1;
        var totalSteps = 3;

        $('.next-step').click(function () {
            if (currentStep < totalSteps) {
                $('#step' + currentStep).removeClass('active').hide();
                currentStep++;
                $('#step' + currentStep).addClass('active').show();
            }
        });

        $('.prev-step').click(function () {
            if (currentStep > 1) {
                $('#step' + currentStep).removeClass('active').hide();
                currentStep--;
                $('#step' + currentStep).addClass('active').show();
            }
        });
    });
</script>
<?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/bursary/resources/views/admin/users/show2.blade.php ENDPATH**/ ?>