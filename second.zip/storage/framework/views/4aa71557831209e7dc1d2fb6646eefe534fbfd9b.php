<?php $__env->startSection('title'); ?>
    Update Role
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/fontawesome-free/css/all.min.css')); ?>">

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/dist/css/adminlte.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(url('Admin/css/role/style.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h3>Update Role: <?php echo e($role->name); ?></h3>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('role.index')); ?>">Roles</a></li>
                           
                            <li class="breadcrumb-item active">Update</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-info">
                            <div class="card-header">
                                <h3 class="card-title">Update Role: <?php echo e($role->name); ?></h3>
                                <div class="card-tools">

                                </div>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                            <form method="POST" action="<?php echo e(route('role.update', $role->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="role name">Role Name</label>
                                        <input type="text"readonly name='name' id="name"
                                            class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e($role->name); ?>" placeholder="Role Name" autocomplete="off">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="row px-1">
                                        <div class="col-md-3 mt-2">
                                            <input type="checkbox" id="select-all" name="select_all">
                                            <label style="font-weight:normal" for="select-all">Assign All
                                                Permissions</label>
                                        </div>
                                    </div>

                                    <hr class="py-0 my-0">

                                    
                                    <div class="row pt-2">
                                        <div class="col-md-12 permissions-group">
                                            <div class="px-1">
                                                <input type="checkbox" id="select-all-user" class="group-checkbox"
                                                    name="select_all_user">
                                                <label style="font-weight:bold" for="select-all-user"> User
                                                    Permissions</label>
                                            </div>
                                            <div class="permissions-row">
                                                
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($permission->name === 'manage user'): ?>
                                                        <div class="permission-item">
                                                            <input type="checkbox" id="<?php echo e($permission->name); ?>"
                                                                name="permissions[]" value="<?php echo e($permission->id); ?>"
                                                                <?php echo e($role->permissions->pluck('id')->contains($permission->id) ? 'checked' : ''); ?>>
                                                            <label style="font-weight:normal"
                                                                for="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?></label>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($permission->name !== 'manage user' && strpos($permission->name, 'user') !== false): ?>
                                                        <div class="permission-item">
                                                            <input type="checkbox" id="<?php echo e($permission->name); ?>"
                                                                name="permissions[]" value="<?php echo e($permission->id); ?>"
                                                                <?php echo e($role->permissions->pluck('id')->contains($permission->id) ? 'checked' : ''); ?>>
                                                            <label style="font-weight:normal"
                                                                for="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?></label>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                    


                                    
                                    <div class="row">
                                        <div class="col-md-12 permissions-group">
                                            <div class="px-1">
                                                <input type="checkbox" id="select-all-staff" class="group-checkbox"
                                                    name="select_all_staff">
                                                <label style="font-weight:bold" for="select-all-staff"> Staff
                                                    Permissions</label>
                                            </div>
                                            <div class="permissions-row">
                                                
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($permission->name === 'manage staff'): ?>
                                                        <div class="permission-item">
                                                            <input type="checkbox" id="<?php echo e($permission->name); ?>"
                                                                name="permissions[]" value="<?php echo e($permission->id); ?>"
                                                                <?php echo e($role->permissions->pluck('id')->contains($permission->id) ? 'checked' : ''); ?>>
                                                            <label style="font-weight:normal"
                                                                for="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?></label>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($permission->name !== 'manage staff' && strpos($permission->name, 'staff') !== false): ?>
                                                        <div class="permission-item">
                                                            <input type="checkbox" id="<?php echo e($permission->name); ?>"
                                                                name="permissions[]" value="<?php echo e($permission->id); ?>"
                                                                <?php echo e($role->permissions->pluck('id')->contains($permission->id) ? 'checked' : ''); ?>>
                                                            <label style="font-weight:normal"
                                                                for="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?></label>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                    


                                    
                                    <div class="row">
                                        <div class="col-md-12 permissions-group">
                                            <div class="px-1">
                                                <input type="checkbox" id="select-all-role" class="group-checkbox"
                                                    name="select_all_role">
                                                <label style="font-weight:bold" for="select-all-role">Role
                                                    Permissions</label>
                                            </div>
                                            <div class="permissions-row">
                                                
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($permission->name === 'manage role'): ?>
                                                        <div class="permission-item">
                                                            <input type="checkbox" id="<?php echo e($permission->name); ?>"
                                                                name="permissions[]" value="<?php echo e($permission->id); ?>"
                                                                <?php echo e($role->permissions->pluck('id')->contains($permission->id) ? 'checked' : ''); ?>>
                                                            <label style="font-weight:normal"
                                                                for="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?></label>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($permission->name !== 'manage role' && strpos($permission->name, 'role') !== false): ?>
                                                        <div class="permission-item">
                                                            <input type="checkbox" id="<?php echo e($permission->name); ?>"
                                                                name="permissions[]" value="<?php echo e($permission->id); ?>"
                                                                <?php echo e($role->permissions->pluck('id')->contains($permission->id) ? 'checked' : ''); ?>>
                                                            <label style="font-weight:normal"
                                                                for="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?></label>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                    


                                    
                                    
                                    


                                    
                                    <div class="row">
                                        <div class="col-md-12 permissions-group">
                                            <div class="px-1">
                                                <input type="checkbox" id="select-all-application-period"
                                                    class="group-checkbox" name="select_all_application_period">
                                                <label style="font-weight:bold"
                                                    for="select-all-application-period">Application Period
                                                    Permissions</label>
                                            </div>
                                            <div class="permissions-row">
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($permission->name === 'manage application period'): ?>
                                                        <div class="permission-item">
                                                            <input type="checkbox" id="<?php echo e($permission->name); ?>"
                                                                name="permissions[]" value="<?php echo e($permission->id); ?>"
                                                                <?php echo e($role->permissions->pluck('id')->contains($permission->id) ? 'checked' : ''); ?>>
                                                            <label style="font-weight:normal"
                                                                for="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?></label>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($permission->name !== 'manage application period' && strpos($permission->name, 'application period') !== false): ?>
                                                        <div class="permission-item">
                                                            <input type="checkbox" id="<?php echo e($permission->name); ?>"
                                                                name="permissions[]" value="<?php echo e($permission->id); ?>"
                                                                <?php echo e($role->permissions->pluck('id')->contains($permission->id) ? 'checked' : ''); ?>>
                                                            <label style="font-weight:normal"
                                                                for="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?></label>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                    


                                    
                                    <div class="row">
                                        <div class="col-md-12 permissions-group">
                                            <div class="px-1">
                                                <input type="checkbox" id="select-all-bursary" class="group-checkbox"
                                                    name="select_all_bursary">
                                                <label style="font-weight:bold" for="select-all-bursary">Bursary
                                                    Permissions</label>
                                            </div>
                                            <div class="permissions-row">
                                                
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($permission->name === 'manage bursary'): ?>
                                                        <div class="permission-item">
                                                            <input type="checkbox" id="<?php echo e($permission->name); ?>"
                                                                name="permissions[]" value="<?php echo e($permission->id); ?>"
                                                                <?php echo e($role->permissions->pluck('id')->contains($permission->id) ? 'checked' : ''); ?>>
                                                            <label style="font-weight:normal"
                                                                for="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?></label>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(strpos($permission->name, 'bursary') !== false && $permission->name !== 'manage bursary'): ?>
                                                        <div class="permission-item">
                                                            <input type="checkbox" id="<?php echo e($permission->name); ?>"
                                                                name="permissions[]" value="<?php echo e($permission->id); ?>"
                                                                <?php echo e($role->permissions->pluck('id')->contains($permission->id) ? 'checked' : ''); ?>>
                                                            <label style="font-weight:normal"
                                                                for="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?></label>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                    


                                    
                                    <div class="row">
                                        <div class="col-md-12 permissions-group">
                                            <div class="px-1">
                                                <input type="checkbox" id="select-all-system-setting"
                                                    class="group-checkbox" name="select_all_system_setting">
                                                <label style="font-weight:bold" for="select-all-system-setting">System
                                                    Settings Permissions</label>
                                            </div>
                                            <div class="permissions-row">
                                                
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($permission->name === 'manage system setting'): ?>
                                                        <div class="permission-item">
                                                            <input type="checkbox" id="<?php echo e($permission->name); ?>"
                                                                name="permissions[]" value="<?php echo e($permission->id); ?>"
                                                                <?php echo e($role->permissions->pluck('id')->contains($permission->id) ? 'checked' : ''); ?>>
                                                            <label style="font-weight:normal"
                                                                for="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?></label>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(strpos($permission->name, 'system setting') !== false && $permission->name !== 'manage system setting'): ?>
                                                        <div class="permission-item">
                                                            <input type="checkbox" id="<?php echo e($permission->name); ?>"
                                                                name="permissions[]" value="<?php echo e($permission->id); ?>"
                                                                <?php echo e($role->permissions->pluck('id')->contains($permission->id) ? 'checked' : ''); ?>>
                                                            <label style="font-weight:normal"
                                                                for="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?></label>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                    


                                    <!-- Add more sections for other groups as needed -->

                                    <div class="px-1">
                                        <button type="submit" class="btn-md btn btn-success"><i class="fas fa-save"></i>
                                            Update Role</button>
                                    </div>

                                </div>

                                <!-- /.card-body -->
                            </form>
                        </div>
                        <!-- /.card -->

                    </div>
                    <!--/.col (left) -->


                    <!--/.col (right) -->
                </div>
                <!-- /.row -->

            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(url('Admin/plugins/jquery/jquery.min.js')); ?>"></script>

    <!-- Bootstrap 4 -->
    <script src="<?php echo e(url('Admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Custom js -->
    <script src="<?php echo e(url('Admin/js/role/app.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(url('Admin/dist/js/adminlte.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/bursary/resources/views/admin/roles/edit.blade.php ENDPATH**/ ?>