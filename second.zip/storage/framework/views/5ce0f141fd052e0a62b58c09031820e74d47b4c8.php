<!DOCTYPE html>
<html>
<head>
    <title>Laravel 10 ChartJS Chart Example - ItSolutionStuff.com</title>
</head>
    
<body>
    <h1>Laravel 10 ChartJS Chart Example - ItSolutionStuff.com</h1>
    <div style="width: 80%">
        <canvas id="chart"></canvas>
    </div></body>
  
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  
<script type="text/javascript">
 
 var totalApplications = <?php echo json_encode($totalApplications, 15, 512) ?>;
        var approvalPercentages = <?php echo json_encode($approvalPercentages, 15, 512) ?>;

        var ctx = document.getElementById('chart').getContext('2d');
        var chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: Object.keys(totalApplications),
                datasets: [{
                    label: 'Approval Percentage',
                    data: Object.values(approvalPercentages),
                    backgroundColor: 'rgba(75, 192, 192, 0.6)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        stepSize: 10,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        },
                        title: {
                            display: true,
                            text: 'Approval Percentage'
                        }
                    }
                }
            }
        });
  
</script>
</html><?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/bursary/resources/views/chart/chart.blade.php ENDPATH**/ ?>