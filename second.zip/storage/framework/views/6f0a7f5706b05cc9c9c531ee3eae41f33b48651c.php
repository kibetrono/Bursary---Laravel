<h1>Welcome to our system!</h1>

<p>Your account has been created successfully. You can now log in using your email address and password.</p>

<p>Your email address: <?php echo e($user->email); ?></p>

<p>Your password: <?php echo e($user->password); ?></p>

<p>Please click the button below to log in.</p>

<a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Log in</a><?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/bursary/resources/views/emails/welcome.blade.php ENDPATH**/ ?>