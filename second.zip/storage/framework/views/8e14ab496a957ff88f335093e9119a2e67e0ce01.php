<?php $__env->startSection('title'); ?>
    Update Applicant: <?php echo e($bursaryapplied->first_name); ?> <?php echo e($bursaryapplied->last_name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/fontawesome-free/css/all.min.css')); ?>">

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/dist/css/adminlte.min.css')); ?>">

    <!-- Select2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
    

    
    <link rel="stylesheet" href="<?php echo e(url('Admin/css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('Admin/css/bursary/edit.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Application for: <?php echo e($bursaryapplied->first_name); ?> <?php echo e($bursaryapplied->last_name); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">
                                <a href="<?php echo e(route('bursary.index')); ?>">Bursary Applications</a>
                            </li>
                            <li class="breadcrumb-item active">Update</li>
                        </ol>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <?php echo $__env->make('layouts.flash-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                </div>
            </div><!-- /.container-fluid -->

        </section>

        <?php
            $startYear = 2000; // Start year
            $endYear = date('Y'); // Current year
        ?>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-info">
                            <div class="card-header">
                                <h3 class="card-title">Apply Bursary</h3>
                                <div class="card-tools">

                                </div>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                            <div class="card-body">
                                <form id="application_form" method="POST"
                                    action="<?php echo e(route('admin.update.bursary', $bursaryapplied->id)); ?>" class="bursary-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    
                                    <div class="form-section">
                                        <div class="row">
                                            <div class="col-md-12 m-1">
                                                <h5 class="text-center text-bold">Personal Details</h5>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group first_name required">
                                                    <label class="control-label" for="first_name">First Name:</label>
                                                    <input type="text" id="first_name"
                                                        class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="first_name" aria-required="true" placeholder="First name"
                                                        value="<?php echo e($bursaryapplied->first_name); ?>" required>
                                                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group last_name required">
                                                    <label class="control-label" for="last_name">Last Name:</label>
                                                    <input type="text" id="last_name"
                                                        class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="last_name" aria-required="true" placeholder="Last name"
                                                        value="<?php echo e($bursaryapplied->last_name); ?>" required>
                                                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group gender required">
                                                    <label class="control-label" for="gender">Gender:</label>
                                                    <select id="gender" name="gender"
                                                        class="form-control <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                                        <option value="male"
                                                            <?php echo e($bursaryapplied->gender === 'male' ? 'selected' : ''); ?>>Male
                                                        </option>
                                                        <option value="female"
                                                            <?php echo e($bursaryapplied->gender === 'female' ? 'selected' : ''); ?>>
                                                            Female</option>
                                                        <option value="others"
                                                            <?php echo e($bursaryapplied->gender === 'others' ? 'selected' : ''); ?>>
                                                            Others</option>
                                                    </select>
                                                    <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>



                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group id_or_passport_no required">
                                                    <label class="control-label" for="id_or_passport_no">ID/Passport
                                                        no.:</label>
                                                    <input type="number" id="id_or_passport_no"
                                                        class="form-control <?php $__errorArgs = ['id_or_passport_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="id_or_passport_no" aria-required="true"
                                                        placeholder="ID or passport number"
                                                        value="<?php echo e($bursaryapplied->id_or_passport_no); ?>">
                                                    <?php $__errorArgs = ['id_or_passport_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group date_of_birth required">
                                                    <label class="control-label" for="date_of_birth">Date of Birth:</label>
                                                    <input type="date" id="date_of_birth"
                                                        class="form-control <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="date_of_birth" aria-required="true"
                                                        value="<?php echo e(\Carbon\Carbon::parse($bursaryapplied->date_of_birth)->format('Y-m-d')); ?>"
                                                        required>
                                                    <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group telephone_number required">
                                                    <label class="control-label" for="telephone_number">Telephone
                                                        Number:</label>
                                                    <input type="text" id="telephone_number"
                                                        class="form-control <?php $__errorArgs = ['telephone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="telephone_number" aria-required="true"
                                                        placeholder="Telephone number"
                                                        value="<?php echo e($bursaryapplied->telephone_number); ?>">
                                                    <?php $__errorArgs = ['telephone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                    

                                    
                                    <div class="form-section">
                                        <div class="row">
                                            <div class="col-md-12 m-1">
                                                <h5 class="text-center text-bold">Family Background Information</h5>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group parental_status required">
                                                    <label class="control-label" for="parental_status">Parental
                                                        Status:</label>
                                                    <select id="parental_status" name="parental_status"
                                                        class="form-control <?php $__errorArgs = ['parental_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        required>
                                                        <option value="Single Parent"
                                                            <?php echo e($bursaryapplied->parental_status === 'Single Parent' ? 'selected' : ''); ?>>
                                                            Single Parent</option>
                                                        <option value="One Parent Dead"
                                                            <?php echo e($bursaryapplied->parental_status === 'One Parent Dead' ? 'selected' : ''); ?>>
                                                            One Parent Dead</option>
                                                        <option value="Both Parents Dead"
                                                            <?php echo e($bursaryapplied->parental_status === 'Both Parents Dead' ? 'selected' : ''); ?>>
                                                            Both Parents Dead</option>
                                                        <option value="Both Parents Alive"
                                                            <?php echo e($bursaryapplied->parental_status === 'Both Parents Alive' ? 'selected' : ''); ?>>
                                                            Both Parents Alive</option>
                                                        <option value="Others"
                                                            <?php echo e($bursaryapplied->parental_status === 'Others' ? 'selected' : ''); ?>>
                                                            Others</option>
                                                    </select>
                                                    <?php $__errorArgs = ['parental_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group number_of_siblings required">
                                                    <label class="control-label" for="number_of_siblings">Number of
                                                        Siblings:</label>
                                                    <input type="number" id="number_of_siblings"
                                                        class="form-control <?php $__errorArgs = ['number_of_siblings'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="number_of_siblings" aria-required="true"
                                                        placeholder="Number of siblings"
                                                        value="<?php echo e($bursaryapplied->number_of_siblings); ?>" required>
                                                    <?php $__errorArgs = ['number_of_siblings'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group estimated_family_income required">
                                                    <label class="control-label" for="estimated_family_income">Estimated
                                                        Family Income:</label>
                                                    <input type="number" id="estimated_family_income"
                                                        class="form-control <?php $__errorArgs = ['estimated_family_income'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="estimated_family_income" aria-required="true"
                                                        placeholder="Family income(yearly)"
                                                        value="<?php echo e($bursaryapplied->estimated_family_income); ?>" required>
                                                    <?php $__errorArgs = ['estimated_family_income'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <h6><b>Father's Information:</b></h6>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group fathers_firstname required">
                                                    <label class="control-label" for="fathers_firstname">First
                                                        Name:</label>
                                                    <input type="text" id="fathers_firstname"
                                                        class="form-control <?php $__errorArgs = ['fathers_firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="fathers_firstname" aria-required="true"
                                                        placeholder="Father's firstname"
                                                        value="<?php echo e($bursaryapplied->fathers_firstname); ?>">
                                                    <?php $__errorArgs = ['fathers_firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group fathers_lastname required">
                                                    <label class="control-label" for="fathers_lastname">Last Name:</label>
                                                    <input type="text" id="fathers_lastname"
                                                        class="form-control <?php $__errorArgs = ['fathers_lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="fathers_lastname" aria-required="true"
                                                        placeholder="Father's lastname"
                                                        value="<?php echo e($bursaryapplied->fathers_lastname); ?>">
                                                    <?php $__errorArgs = ['fathers_lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group fathers_telephone_number required">
                                                    <label class="control-label" for="fathers_telephone_number">Telephone
                                                        Number:</label>
                                                    <input type="number" id="fathers_telephone_number"
                                                        class="form-control <?php $__errorArgs = ['fathers_telephone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="fathers_telephone_number" aria-required="true"
                                                        placeholder="Father's phone number"
                                                        value="<?php echo e($bursaryapplied->fathers_telephone_number); ?>">
                                                    <?php $__errorArgs = ['fathers_telephone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group fathers_occupation required">
                                                    <label class="control-label"
                                                        for="fathers_occupation">Occupation:</label>
                                                    <input type="text" id="fathers_occupation"
                                                        class="form-control <?php $__errorArgs = ['fathers_occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="fathers_occupation" aria-required="true"
                                                        placeholder="Father's occupation"
                                                        value="<?php echo e($bursaryapplied->fathers_occupation); ?>">
                                                    <?php $__errorArgs = ['fathers_occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group fathers_employment_type required">
                                                    <label class="control-label" for="fathers_employment_type">Employment
                                                        Type:</label>
                                                    <select id="fathers_employment_type" name="fathers_employment_type"
                                                        class="form-control <?php $__errorArgs = ['fathers_employment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                        <option value="" selected disabled>Select father's employment
                                                            type</option>
                                                        <option value="permanent"
                                                            <?php echo e($bursaryapplied->fathers_employment_type === 'permanent' ? 'selected' : ''); ?>>
                                                            Permanent</option>
                                                        <option value="contractual"
                                                            <?php echo e($bursaryapplied->fathers_employment_type === 'contractual' ? 'selected' : ''); ?>>
                                                            Contractual</option>
                                                        <option value="casual"
                                                            <?php echo e($bursaryapplied->fathers_employment_type === 'casual' ? 'selected' : ''); ?>>
                                                            Casual</option>
                                                        <option value="retired"
                                                            <?php echo e($bursaryapplied->fathers_employment_type === 'retired' ? 'selected' : ''); ?>>
                                                            Retired</option>
                                                        <option value="self_employed"
                                                            <?php echo e($bursaryapplied->fathers_employment_type === 'self_employed' ? 'selected' : ''); ?>>
                                                            Self Employed</option>
                                                    </select>
                                                    <?php $__errorArgs = ['fathers_employment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <h6><b>Mother's Information:</b></h6>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group mothers_firstname required">
                                                    <label class="control-label" for="mothers_firstname">First
                                                        Name:</label>
                                                    <input type="text" id="mothers_firstname"
                                                        class="form-control <?php $__errorArgs = ['mothers_firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="mothers_firstname" aria-required="true"
                                                        placeholder="Mother's firstname"
                                                        value=<?php echo e($bursaryapplied->mothers_firstname); ?>>
                                                    <?php $__errorArgs = ['mothers_firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group mothers_lastname required">
                                                    <label class="control-label" for="mothers_lastname">Last Name:</label>
                                                    <input type="text" id="mothers_lastname"
                                                        class="form-control <?php $__errorArgs = ['mothers_lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="mothers_lastname" aria-required="true"
                                                        placeholder="Mother's lastname"
                                                        value=<?php echo e($bursaryapplied->mothers_lastname); ?>>
                                                    <?php $__errorArgs = ['mothers_lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group mothers_telephone_number required">
                                                    <label class="control-label" for="mothers_telephone_number">Telephone
                                                        Number:</label>
                                                    <input type="number" id="mothers_telephone_number"
                                                        class="form-control <?php $__errorArgs = ['mothers_telephone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="mothers_telephone_number" aria-required="true"
                                                        placeholder="Mother's phone number"
                                                        value=<?php echo e($bursaryapplied->mothers_telephone_number); ?>>
                                                    <?php $__errorArgs = ['mothers_telephone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group mothers_occupation required">
                                                    <label class="control-label"
                                                        for="mothers_occupation">Occupation:</label>
                                                    <input type="text" id="mothers_occupation"
                                                        class="form-control <?php $__errorArgs = ['mothers_occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="mothers_occupation" aria-required="true"
                                                        placeholder="Mother's occupation"
                                                        value=<?php echo e($bursaryapplied->mothers_occupation); ?>>
                                                    <?php $__errorArgs = ['mothers_occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group mothers_employment_type required">
                                                    <label class="control-label" for="mothers_employment_type">Employment
                                                        Type:</label>
                                                    <select id="mothers_employment_type" name="mothers_employment_type"
                                                        class="form-control <?php $__errorArgs = ['mothers_employment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                        <option value="" selected disabled>Select Mother's employment
                                                            type</option>
                                                        <option value="permanent"
                                                            <?php echo e($bursaryapplied->mothers_employment_type === 'permanent' ? 'selected' : ''); ?>>
                                                            Permanent</option>
                                                        <option value="contractual"
                                                            <?php echo e($bursaryapplied->mothers_employment_type === 'contractual' ? 'selected' : ''); ?>>
                                                            Contractual</option>
                                                        <option value="casual"
                                                            <?php echo e($bursaryapplied->mothers_employment_type === 'casual' ? 'selected' : ''); ?>>
                                                            Casual</option>
                                                        <option value="retired"
                                                            <?php echo e($bursaryapplied->mothers_employment_type === 'retired' ? 'selected' : ''); ?>>
                                                            Retired</option>
                                                        <option value="self_employed"
                                                            <?php echo e($bursaryapplied->mothers_employment_type === 'self_employed' ? 'selected' : ''); ?>>
                                                            Self Employed</option>
                                                    </select>
                                                    <?php $__errorArgs = ['mothers_employment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <h6><b>Guardian's Information:</b></h6>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group guardians_firstname required">
                                                    <label class="control-label" for="guardians_firstname">First
                                                        Name:</label>
                                                    <input type="text" id="guardians_firstname"
                                                        class="form-control <?php $__errorArgs = ['guardians_firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="guardians_firstname" aria-required="true"
                                                        placeholder="Guardian's firstname"
                                                        value=<?php echo e($bursaryapplied->guardians_firstname); ?>>
                                                    <?php $__errorArgs = ['guardians_firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group guardians_lastname required">
                                                    <label class="control-label" for="guardians_lastname">Last
                                                        Name:</label>
                                                    <input type="text" id="guardians_lastname"
                                                        class="form-control <?php $__errorArgs = ['guardians_lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="guardians_lastname" aria-required="true"
                                                        placeholder="Guardian's lastname"
                                                        value=<?php echo e($bursaryapplied->guardians_lastname); ?>>
                                                    <?php $__errorArgs = ['guardians_lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group guardians_telephone_number required">
                                                    <label class="control-label"
                                                        for="guardians_telephone_number">Telephone
                                                        Number:</label>
                                                    <input type="number" id="guardians_telephone_number"
                                                        class="form-control <?php $__errorArgs = ['guardians_telephone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="guardians_telephone_number" aria-required="true"
                                                        placeholder="Guardian's phone number"
                                                        value=<?php echo e($bursaryapplied->guardians_telephone_number); ?>>
                                                    <?php $__errorArgs = ['guardians_telephone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group guardians_occupation required">
                                                    <label class="control-label"
                                                        for="guardians_occupation">Occupation:</label>
                                                    <input type="text" id="guardians_occupation"
                                                        class="form-control <?php $__errorArgs = ['guardians_occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="guardians_occupation" aria-required="true"
                                                        placeholder="Guardian's occupation"
                                                        value=<?php echo e($bursaryapplied->guardians_occupation); ?>>
                                                    <?php $__errorArgs = ['guardians_occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group guardians_employment_type required">
                                                    <label class="control-label"
                                                        for="guardians_employment_type">Employment
                                                        Type:</label>
                                                    <select id="guardians_employment_type"
                                                        name="guardians_employment_type"
                                                        class="form-control <?php $__errorArgs = ['guardians_employment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                        <option value="" selected disabled>Select Guardian's
                                                            employment
                                                            type</option>
                                                        <option value="permanent"
                                                            <?php echo e($bursaryapplied->guardians_employment_type === 'permanent' ? 'selected' : ''); ?>>
                                                            Permanent</option>
                                                        <option value="contractual"
                                                            <?php echo e($bursaryapplied->guardians_employment_type === 'contractual' ? 'selected' : ''); ?>>
                                                            Contractual</option>
                                                        <option value="casual"
                                                            <?php echo e($bursaryapplied->guardians_employment_type === 'casual' ? 'selected' : ''); ?>>
                                                            Casual</option>
                                                        <option value="retired"
                                                            <?php echo e($bursaryapplied->guardians_employment_type === 'retired' ? 'selected' : ''); ?>>
                                                            Retired</option>
                                                        <option value="self_employed"
                                                            <?php echo e($bursaryapplied->guardians_employment_type === 'self_employed' ? 'selected' : ''); ?>>
                                                            Self Employed</option>
                                                    </select>
                                                    <?php $__errorArgs = ['guardians_employment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    

                                    
                                    <div class="form-section">
                                        <div class="row">
                                            <div class="col-md-12 m-1">
                                                <h5 class="text-center text-bold">Address Information</h5>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group location required">
                                                    <label class="control-label" for="location">Location:</label>
                                                    <input type="text" id="location"
                                                        class="form-control <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="location" aria-required="true" placeholder="Location name"
                                                        value=<?php echo e($bursaryapplied->location); ?> required>
                                                    <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group sub_location required">
                                                    <label class="control-label" for="sub_location">Sub Location:</label>
                                                    <input type="text" id="sub_location"
                                                        class="form-control <?php $__errorArgs = ['sub_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="sub_location" aria-required="true"
                                                        placeholder="sub location"
                                                        value=<?php echo e($bursaryapplied->sub_location); ?> required>
                                                    <?php $__errorArgs = ['sub_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group ward required">
                                                    <label class="control-label" for="ward">Ward:</label>
                                                    <input type="text" id="ward"
                                                        class="form-control <?php $__errorArgs = ['ward'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="ward" aria-required="true" placeholder="Ward name"
                                                        value=<?php echo e($bursaryapplied->ward); ?> required>
                                                    <?php $__errorArgs = ['ward'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group polling_station required">
                                                    <label class="control-label" for="polling_station">Polling
                                                        station:</label>
                                                    <input type="text" id="polling_station"
                                                        class="form-control <?php $__errorArgs = ['polling_station'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="polling_station" aria-required="true"
                                                        placeholder="Polling station"
                                                        value=<?php echo e($bursaryapplied->polling_station); ?> required>
                                                    <?php $__errorArgs = ['polling_station'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    

                                    
                                    <div class="form-section">
                                        <div class="row">
                                            <div class="col-md-12 m-1">
                                                <h5 class="text-center text-bold">School Details</h5>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group institution_name required">
                                                    <label class="control-label" for="date_of_birth">Name of
                                                        school/college/university:</label>
                                                    <input type="text" id="institution_name"
                                                        class="form-control <?php $__errorArgs = ['institution_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="institution_name" aria-required="true"
                                                        placeholder="School name"
                                                        value="<?php echo e($bursaryapplied->institution_name); ?>" required>
                                                    <?php $__errorArgs = ['institution_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group adm_or_reg_no required">
                                                    <label class="control-label"
                                                        for="adm_or_reg_no">Admission/Registration
                                                        no.:</label>
                                                    <input type="text" id="adm_or_reg_no"
                                                        class="form-control <?php $__errorArgs = ['adm_or_reg_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="adm_or_reg_no" aria-required="true"
                                                        placeholder="Admission or registration number"
                                                        value="<?php echo e($bursaryapplied->adm_or_reg_no); ?>" required>
                                                    <?php $__errorArgs = ['adm_or_reg_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>


                                            <div class="col-md-4">
                                                <div class="form-group mode_of_study required">
                                                    <label class="control-label" for="mode_of_study">Study Mode:</label>
                                                    <select id="mode_of_study" name="mode_of_study"
                                                        class="form-control <?php $__errorArgs = ['mode_of_study'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        required>
                                                        <option value="" selected disabled>Select study mode</option>
                                                        <option value="day"
                                                            <?php echo e($bursaryapplied->mode_of_study === 'day' ? 'selected' : ''); ?>>
                                                            Day</option>
                                                        <option value="boarding"
                                                            <?php echo e($bursaryapplied->mode_of_study === 'boarding' ? 'selected' : ''); ?>>
                                                            Boarding</option>
                                                        <option value="regular"
                                                            <?php echo e($bursaryapplied->mode_of_study === 'regular' ? 'selected' : ''); ?>>
                                                            Regular</option>
                                                        <option value="parallel"
                                                            <?php echo e($bursaryapplied->mode_of_study === 'parallel' ? 'selected' : ''); ?>>
                                                            Parallel</option>
                                                    </select>
                                                    <?php $__errorArgs = ['mode_of_study'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group year_of_study required">
                                                    <label class="control-label" for="year_of_study">Grade/Class/Year of
                                                        Study:</label>
                                                    <input type="number" id="year_of_study"
                                                        class="form-control <?php $__errorArgs = ['year_of_study'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="year_of_study" aria-required="true"
                                                        placeholder="Grade/class/year of study"
                                                        value="<?php echo e($bursaryapplied->year_of_study); ?>" required>
                                                    <?php $__errorArgs = ['year_of_study'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group course_name required">
                                                    <label class="control-label" for="course_name">Course(tertiary
                                                        institution
                                                        and University):</label>
                                                    <input type="text" id="course_name"
                                                        class="form-control <?php $__errorArgs = ['course_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="course_name" aria-required="true" placeholder="Course name"
                                                        value="<?php echo e($bursaryapplied->course_name); ?>">
                                                    <?php $__errorArgs = ['course_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>



                                            <div class="col-md-4">
                                                <div class="form-group instititution_postal_address required">
                                                    <label class="control-label"
                                                        for="instititution_postal_address">Institution's Postal
                                                        Address:</label>
                                                    <input type="text" id="instititution_postal_address"
                                                        class="form-control <?php $__errorArgs = ['instititution_postal_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="instititution_postal_address" aria-required="true"
                                                        placeholder="Institution's postal address"
                                                        value="<?php echo e($bursaryapplied->instititution_postal_address); ?>"
                                                        required>
                                                    <?php $__errorArgs = ['instititution_postal_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group instititution_telephone_number required">
                                                    <label class="control-label"
                                                        for="instititution_telephone_number">Institution's Telephone
                                                        Number:</label>
                                                    <input type="text" id="instititution_telephone_number"
                                                        class="form-control <?php $__errorArgs = ['instititution_telephone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="instititution_telephone_number" aria-required="true"
                                                        placeholder="Institution's telephone number"
                                                        value="<?php echo e($bursaryapplied->instititution_telephone_number); ?>"
                                                        required>
                                                    <?php $__errorArgs = ['instititution_telephone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <p><b>Fees Payable:</b></p>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group total_fees_payable required">
                                                    <label class="control-label" for="total_fees_payable">Total Fees
                                                        Payable:</label>
                                                    <input type="number" id="total_fees_payable"
                                                        class="form-control <?php $__errorArgs = ['total_fees_payable'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="total_fees_payable" aria-required="true"
                                                        placeholder="Total fees payable"
                                                        value="<?php echo e($bursaryapplied->total_fees_payable); ?>" required>
                                                    <?php $__errorArgs = ['total_fees_payable'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group total_fees_paid required">
                                                    <label class="control-label" for="total_fees_paid">Total Fees
                                                        Paid:</label>
                                                    <input type="number" id="total_fees_paid"
                                                        class="form-control <?php $__errorArgs = ['total_fees_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="total_fees_paid" aria-required="true"
                                                        placeholder="Total amount paid"
                                                        value="<?php echo e($bursaryapplied->total_fees_paid); ?>" required>
                                                    <?php $__errorArgs = ['total_fees_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group fee_balance required">
                                                    <label class="control-label" for="fee_balance">Fee Balance:</label>
                                                    <input type="number" id="fee_balance"
                                                        class="form-control <?php $__errorArgs = ['fee_balance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="fee_balance" aria-required="true"
                                                        placeholder="Balance amount"
                                                        value="<?php echo e($bursaryapplied->fee_balance); ?>" required>
                                                    <?php $__errorArgs = ['fee_balance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <p><b>School/College/University Account Details:</b></p>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group bank_name required">
                                                    <label class="control-label" for="bank_name">Name of Bank:</label>
                                                    <select id="bank_name" name="bank_name"
                                                        class="form-control <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        required>
                                                        <option value="" selected disabled>Select bank name</option>
                                                        <option value="Equity Bank"
                                                            <?php echo e($bursaryapplied->bank_name === 'Equity Bank' ? 'selected' : ''); ?>>
                                                            Equity Bank</option>
                                                        <option value="KCB Bank (Kenya Commercial Bank)"
                                                            <?php echo e($bursaryapplied->bank_name === 'KCB Bank (Kenya Commercial Bank)' ? 'selected' : ''); ?>>
                                                            KCB Bank (Kenya Commercial Bank)</option>
                                                        <option value="Cooperative Bank of Kenya"
                                                            <?php echo e($bursaryapplied->bank_name === 'Cooperative Bank of Kenya' ? 'selected' : ''); ?>>
                                                            Cooperative Bank of Kenya</option>
                                                        <option value="Barclays Bank of Kenya (Absa Bank Kenya PLC)"
                                                            <?php echo e($bursaryapplied->bank_name === 'Barclays Bank of Kenya (Absa Bank Kenya PLC)' ? 'selected' : ''); ?>>
                                                            Barclays Bank of Kenya (Absa Bank Kenya PLC)</option>
                                                        <option value="Standard Chartered Bank Kenya"
                                                            <?php echo e($bursaryapplied->bank_name === 'Standard Chartered Bank Kenya' ? 'selected' : ''); ?>>
                                                            Standard Chartered Bank Kenya</option>
                                                        <option value="CFC Stanbic Bank (Stanbic Bank Kenya)"
                                                            <?php echo e($bursaryapplied->bank_name === 'CFC Stanbic Bank (Stanbic Bank Kenya)' ? 'selected' : ''); ?>>
                                                            CFC Stanbic Bank (Stanbic Bank Kenya)</option>
                                                        <option value="Diamond Trust Bank Kenya"
                                                            <?php echo e($bursaryapplied->bank_name === 'Diamond Trust Bank Kenya' ? 'selected' : ''); ?>>
                                                            Diamond Trust Bank Kenya</option>
                                                        <option value="National Bank of Kenya"
                                                            <?php echo e($bursaryapplied->bank_name === 'National Bank of Kenya' ? 'selected' : ''); ?>>
                                                            National Bank of Kenya</option>
                                                        <option value="NIC Bank (Now part of NCBA Bank)"
                                                            <?php echo e($bursaryapplied->bank_name === 'NIC Bank (Now part of NCBA Bank)' ? 'selected' : ''); ?>>
                                                            NIC Bank (Now part of NCBA Bank)</option>
                                                        <option
                                                            value="Commercial Bank of Africa (CBA) - Merged with NIC Bank to form NCBA Bank"
                                                            <?php echo e($bursaryapplied->bank_name === 'Commercial Bank of Africa (CBA) - Merged with NIC Bank to form NCBA Bank' ? 'selected' : ''); ?>>
                                                            Commercial Bank of Africa (CBA) - Merged with NIC Bank to form
                                                            NCBA Bank</option>
                                                        <option value="I&M Bank Kenya"
                                                            <?php echo e($bursaryapplied->bank_name === 'I&M Bank Kenya' ? 'selected' : ''); ?>>
                                                            I&M Bank Kenya</option>
                                                        <option value="Ecobank Kenya"
                                                            <?php echo e($bursaryapplied->bank_name === 'Ecobank Kenya' ? 'selected' : ''); ?>>
                                                            Ecobank Kenya</option>
                                                        <option value="Bank of Africa Kenya"
                                                            <?php echo e($bursaryapplied->bank_name === 'Bank of Africa Kenya' ? 'selected' : ''); ?>>
                                                            Bank of Africa Kenya</option>
                                                        <option value="Family Bank Kenya"
                                                            <?php echo e($bursaryapplied->bank_name === 'Family Bank Kenya' ? 'selected' : ''); ?>>
                                                            Family Bank Kenya</option>
                                                        <option value="Gulf African Bank"
                                                            <?php echo e($bursaryapplied->bank_name === 'Gulf African Bank' ? 'selected' : ''); ?>>
                                                            Gulf African Bank</option>
                                                        <option value="Credit Bank Kenya"
                                                            <?php echo e($bursaryapplied->bank_name === 'Credit Bank Kenya' ? 'selected' : ''); ?>>
                                                            Credit Bank Kenya</option>
                                                        <option value="Prime Bank Kenya"
                                                            <?php echo e($bursaryapplied->bank_name === 'Prime Bank Kenya' ? 'selected' : ''); ?>>
                                                            Prime Bank Kenya</option>
                                                        <option value="Sidian Bank (formerly K-Rep Bank)"
                                                            <?php echo e($bursaryapplied->bank_name === 'Sidian Bank (formerly K-Rep Bank)' ? 'selected' : ''); ?>>
                                                            Sidian Bank (formerly K-Rep Bank)</option>
                                                        <option value="Victoria Commercial Bank"
                                                            <?php echo e($bursaryapplied->bank_name === 'Victoria Commercial Bank' ? 'selected' : ''); ?>>
                                                            Victoria Commercial Bank</option>
                                                        <option value="Housing Finance Company of Kenya"
                                                            <?php echo e($bursaryapplied->bank_name === 'Housing Finance Company of Kenya' ? 'selected' : ''); ?>>
                                                            Housing Finance Company of Kenya</option>
                                                        <option value="Chase Bank Kenya (Currently under receivership)"
                                                            <?php echo e($bursaryapplied->bank_name === 'Chase Bank Kenya (Currently under receivership)' ? 'selected' : ''); ?>>
                                                            Chase Bank Kenya (Currently under receivership)</option>

                                                    </select>
                                                    <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group branch required">
                                                    <label class="control-label" for="branch">Branch:</label>
                                                    <input type="text" id="branch"
                                                        class="form-control <?php $__errorArgs = ['branch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="branch" aria-required="true" placeholder="Branch"
                                                        value="<?php echo e($bursaryapplied->branch); ?>" required>
                                                    <?php $__errorArgs = ['branch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group account_number required">
                                                    <label class="control-label" for="account_number">Account
                                                        Number:</label>
                                                    <input type="number" id="account_number"
                                                        class="form-control <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="account_number" aria-required="true"
                                                        placeholder="Account number"
                                                        value="<?php echo e($bursaryapplied->account_number); ?>" required>
                                                    <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    

                                    

                                    

                                    

                                    <div class="form-navigation">
                                        <button type="button"
                                            class="btn-sm previous btn btn-info float-left">Previous</button>
                                        <button type="button" class="btn-sm next btn btn-info float-right">Next</button>
                                        <button type="submit" class="btn-sm btn btn-success float-right">Update
                                            Application</button>
                                    </div>

                                    
                                    

                                </form>
                            </div>
                        </div>
                        <!-- /.card -->


                    </div>
                    <!--/.col (left) -->
                    <!-- right column -->

                    <!--/.col (right) -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->



    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(url('Admin/plugins/jquery/jquery.min.js')); ?>"></script>

    <!-- Bootstrap 4 -->
    <script src="<?php echo e(url('Admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <script src="<?php echo e(url('Admin/plugins/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(url('Admin/dist/js/adminlte.min.js')); ?>"></script>



    

    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <!-- Select2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>

    <script>
        $(document).ready(function() {

            // Initialize Select2
            $('#bank_name').select2();

            // Set option selected onchange
            $('#user_selected').change(function() {
                var value = $(this).val();

                // Set selected 
                $('#bank_name').val(value);
                $('#bank_name').select2().trigger('change');

            });
        });
    </script>
    


    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.9.2/parsley.min.js"
        integrity="sha512-eyHL1atYNycXNXZMDndxrDhNAegH2BDWt1TmkXJPoGf1WLlNYt08CSjkqF5lnCRmdm3IrkHid8s2jOUY4NIZVQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    

    
    <script>
        $(function() {
            var $sections = $('.form-section');

            function navigateTo(index) {
                $sections.removeClass('current').eq(index).addClass('current');
                $('.form-navigation .previous').toggle(index > 0);
                var atTheEnd = index >= $sections.length - 1;
                $('.form-navigation .next').toggle(!atTheEnd);
                $('.form-navigation [type=submit]').toggle(atTheEnd);
            }

            function currentIndex() {
                return $sections.index($sections.filter('.current'))
            }

            $('.form-navigation .previous').click(function() {
                navigateTo(currentIndex() - 1)
            });

            $('.form-navigation .next').click(function() {
                $('.bursary-form').parsley().whenValidate({
                    group: 'block-' + currentIndex()
                }).done(function() {
                    navigateTo(currentIndex() + 1)
                });
            });
            $sections.each(function(index, section) {
                $(section).find(':input').attr('data-parsley-group', 'block-' + index);

            });

            navigateTo(0);
        })
    </script>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/bursary/resources/views/admin/bursary/edit.blade.php ENDPATH**/ ?>