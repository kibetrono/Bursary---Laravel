<?php $__env->startSection('title'); ?>
<?php echo e($data->first_name); ?> <?php echo e($data->last_name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/fontawesome-free/css/all.min.css')); ?>">

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/dist/css/adminlte.min.css')); ?>">
    <style>
        input{
            background-color: #F4F6F9;
            border: unset;
            border-radius: 5px;
            padding-left: 8px
        }
        input:focus{
            outline: none
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h3>Applicant: <?php echo e($data->first_name); ?> <?php echo e($data->last_name); ?></h3>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">
                                <a href="<?php echo e(route('bursary.index')); ?>">Bursary applications</a>
                            </li>
                            
                        </ol>
                    </div>
                </div>

            </div><!-- /.container-fluid -->

        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-info">
                                <h3 class="card-title">Applicants Information</h3>
                                <div class="card-tools">
                                    
                                </div>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">

                                <div class="row">
                                    <div class="col-md-4"></div><div class="col-md-4"><h5>Personal Information</h5></div><div class="col-md-4"></div>
                                   
                                    <div class="col-md-12">
                                    
                                </div>


                                    
                                </div>
                                <div class="row">
                                    <div class="col-md-4"></div>
                                    <div class="col-md-4">
                                        <h5>Family Background Information</h5>
                                    </div>
                                    <div class="col-md-4"></div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4"></div>
                                    <div class="col-md-4">
                                        <h5>School Details</h5>
                                    </div>
                                    <div class="col-md-4"></div>
                                     
                                </div>

                                <div class="row">
                                    <div class="col-md-4"></div>
                                    <div class="col-md-4">
                                        <h5>Key Attachments</h5>
                                    </div>
                                    <div class="col-md-4"></div>

                                </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                <div class="row">
                                    <div class="col-md-6 text-center">
                                        <form action="">
                                            <button style="border-radius:4px" class="btn-sm btn btn-success">Approve Application</button>
                                        </form>
                                    </div>
                                    <div class="col-md-6">
                                        <form action="">
                                            <button style="border-radius:4px" class="btn-sm btn btn-danger">Reject Application</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(url('Admin/plugins/jquery/jquery.min.js')); ?>"></script>

    <!-- Bootstrap 4 -->
    <script src="<?php echo e(url('Admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(url('Admin/dist/js/adminlte.min.js')); ?>"></script>

    <!-- AdminLTE for demo purposes -->
    <script src="<?php echo e(url('Admin/dist/js/demo.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/bursary/resources/views/admin/bursary/show.blade.php ENDPATH**/ ?>