<?php $__env->startSection('title'); ?>
    <?php echo e($user->name); ?> Approved Bursary Applications
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/plugins/fontawesome-free/css/all.min.css')); ?>">

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(url('Admin/dist/css/adminlte.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(url('Admin/css/main.css')); ?>">
<?php $__env->stopSection(); ?>
<?php
$startIndex = ($approvedBursaries->currentPage() - 1) * $approvedBursaries->perPage();
?>
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h3><?php echo e($user->email); ?></h3>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">
                                <a href="<?php echo e(route('staff.users.show', encrypt($user->id))); ?>"><?php echo e($user->name); ?></a>
                            </li>
                            <li class="breadcrumb-item active">Approved Application List</li>
                        </ol>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <?php echo $__env->make('layouts.flash-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                </div>
            </div><!-- /.container-fluid -->

        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">

                    <!-- /.col -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-info">
                                <h3 class="card-title">Applications Approved By: <?php echo e($user->name); ?></h3>
                                <div class="card-tools">
                                    <form action="<?php echo e(route('staff.view.approved.applications',encrypt($user->id))); ?>" method="GET">

                                        <div class="input-group input-group-sm">
                                            <input type="text" name="approved_search_by_staff" value="<?php echo e($searchTerm); ?>" class="form-control"
                                                placeholder="search by adm/reg number" autocomplete="off">

                                            <div class="input-group-append">
                                                <button type="submit" class="btn btn-default">
                                                    <i class="fas fa-search"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </form>

                                </div>
                                
                            </div>
                         
                            <!-- /.card-header -->
                            <div class="card-body table-responsive p-1">
                                <table class="table table-hover text-nowrap table-bordered">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Gender</th>
                                            <th>Institution</th>
                                            <th>Adm/Reg no.</th>
                                            <th>Total Fees</th>
                                            <th>Paid</th>
                                            <th>Balance</th>
                                            <th>Date Applied</th>
                                            <th>Date Approved</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $approvedBursaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$approvedBursary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($startIndex + $index + 1); ?></td>
                                                <td><?php echo e($approvedBursary->first_name); ?> <?php echo e($approvedBursary->last_name); ?></td>
                                                <td><?php echo e($approvedBursary->gender); ?></td>
                                                <td><?php echo e($approvedBursary->institution_name); ?></td>
                                                <td><?php echo e($approvedBursary->adm_or_reg_no); ?></td>
                                                <td><?php echo e($approvedBursary->total_fees_payable); ?></td>
                                                <td><?php echo e($approvedBursary->total_fees_paid); ?></td>
                                                <td><?php echo e($approvedBursary->fee_balance); ?></td>
                                                <td><?php echo e($approvedBursary->created_at->format('Y-m-d')); ?></td>
                                                <td><?php echo e($approvedBursary->updated_at->format('Y-m-d')); ?></td>
                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td class="fas fa-folder-open"> No Application Approved By <?php echo e(ucfirst($user->name)); ?></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        <?php endif; ?>


                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>

                                        </tr>
                                    </tfoot>
                                </table>
                                <div class="row">
                                    <div class="col-md-12 pt-2">
                                        <?php if($approvedBursaries->hasPages()): ?>
                                            <div class="d-flex justify-content-end">
                                                <nav aria-label="Page navigation">
                                                    <ul class="pagination">
                                                        
                                                        <li
                                                            class="page-item <?php echo e($approvedBursaries->onFirstPage() ? 'disabled' : ''); ?>">
                                                            <a class="page-link"
                                                                href="<?php echo e($approvedBursaries->previousPageUrl()); ?>"
                                                                aria-label="Previous">
                                                                <span aria-hidden="true">&laquo;</span>
                                                            </a>
                                                        </li>

                                                        
                                                        <?php $__currentLoopData = $approvedBursaries->getUrlRange(1, $approvedBursaries->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li
                                                                class="page-item <?php echo e($approvedBursaries->currentPage() === $page ? 'active' : ''); ?>">
                                                                <a class="page-link"
                                                                    href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        
                                                        <li
                                                            class="page-item <?php echo e(!$approvedBursaries->hasMorePages() ? 'disabled' : ''); ?>">
                                                            <a class="page-link" href="<?php echo e($approvedBursaries->nextPageUrl()); ?>"
                                                                aria-label="Next">
                                                                <span aria-hidden="true">&raquo;</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->


    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(url('Admin/plugins/jquery/jquery.min.js')); ?>"></script>

    <!-- Bootstrap 4 -->
    <script src="<?php echo e(url('Admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- AdminLTE App -->
    <script src="<?php echo e(url('Admin/dist/js/adminlte.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SoftwaresKe/Second/School Management/bursary/resources/views/staff/staff_users/show-approved-applications.blade.php ENDPATH**/ ?>